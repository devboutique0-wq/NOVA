# NOVA - handover prompt (paste this into the next Claude chat together with the zip)

You are continuing an existing Android project called NOVA (Kotlin, Gradle, Vosk offline wake word, foreground mic
service, WebView UI in app/src/main/assets/ui.html). Read HANDOFF_STATUS.md, README_NOVA_V6.md and AUTOPSY_REPORT.md first.
Do NOT restart the project and do NOT recreate what exists. Follow: ADD -> TEST -> INTEGRATE -> REGRESSION TEST -> VERIFY.

## About the user
- Not a programmer. Replies in Hinglish, direct, no theory. ONE step at a time: give the next exact action, then wait for pasted output.
- Never claim DONE / WORKING / VERIFIED without evidence. Use this ladder: ARCHITECTURE ONLY -> STATICALLY VERIFIED -> AUTOMATED TEST VERIFIED -> LOCAL RUNTIME VERIFIED -> TARGET PHONE VERIFIED -> END-TO-END VERIFIED.
- When the user pastes a log: name the exact root cause and say whether it is a project bug or a user command-entry mistake.
- Whenever the user must type commands in Windows, remind them: do not copy the "PS D:\...>" prompt.
- Do not ask the user to re-send the project; ask for the zip only if it is not attached.

## Current state (written WITHOUT a Kotlin compiler / Android SDK / network, so status = STATICALLY VERIFIED at best)
All five planned steps now exist in the zip, but NOTHING has been compiled, unit-tested or run on a phone yet:
1. Original NOVA 6.0, floating card (NovaHud), voice screen control (Control, NovaAccessibilityService), Layer-1 brain (Brain, BrainStore),
   Discover -> Ask -> Add updater (Updater, UpdateManager, InstallReceiver).
2. B signing: app/build.gradle.kts reads NOVA_KEYSTORE_PATH / NOVA_KEYSTORE_PASSWORD / NOVA_KEY_ALIAS / NOVA_KEY_PASSWORD / NOVA_VERSION_CODE;
   workflows: build.yml (loads secrets), make-keystore.yml (run once), release.yml (publishes nova-vc<N>.apk, then refreshes the feed).
3. C feed: tools/build_feed.py + .github/workflows/feed.yml, skillpacks/starter.json, tools/models.json (EMPTY: no model chosen).
   Note: the phone can only read feed.json if the repo is public (or the feed is hosted elsewhere).
4. D self-improve: tools/self_improve.py + self-improve.yml (workflow_dispatch, PR only, protected paths, max 3 files, tests must be green),
   SafetyInvariantsTest.kt, tools/test_self_improve.py. The Python guard tests WERE run in the sandbox and pass.
   Limit: SafetyInvariantsTest covers the pure rule objects, not NovaService wiring, so the owner must still read every PR.
5. E offline model slot: LocalBrain.kt (interface, prompt builder, strict one-line output parser), LocalBrains.kt (slot, 8 s timeout),
   hook in NovaService.handle() after brain.resolve and before the cloud; a model-suggested "tap" always asks a spoken yes.
   NO inference engine is bundled (LocalBrains.factory == null), so behaviour is unchanged until one is added and compile-tested in CI.
Unit tests written, never run: LogicTest, ControlTest, BrainTest, HudMathTest, UpdaterTest, LocalBrainTest, SafetyInvariantsTest.

## What to do next (one step at a time)
A. FIRST: get the build green. Follow SETUP_STEPS.md step 1, run workflow "Build and Test APK", fix every compile/test error from the log.
   Already reviewed statically (no problem found): NovaAccessibilityService companion -> private clickNode, GestureResultCallback, BrainStore
   synchronized/return@synchronized (made explicit `: Unit`), UpdateManager Session.use / signingInfo, InstallReceiver getParcelableExtra, NovaHud listener.
   New and equally unproven: LocalBrain*.kt, the hook in NovaService.handle(), both new test files (check test expectations against Logic.classify first
   if a test fails: the test may be wrong, not the code).
B-D. After the build is green: set the secrets (SETUP_STEPS.md 2-4), run make-keystore once, run Release APK, check that an in-app update installs over the old app.
E. Pick an offline engine (MediaPipe / LiteRT / llama.cpp) and a small open-licensed model, add the engine behind LocalBrains.factory,
   compile-test it in CI, add the model to tools/models.json. Only then claim it works.

## Hard rules (never change without the user's explicit approval)
- Risky actions (call, send, pay, delete, buy...) always need a spoken local "yes". Cloud/LLM output can never approve anything.
- tap/type are refused in package installer, permission screens, system Settings, Play Store, payment/bank apps and NOVA itself; never type into password fields.
- Nothing is downloaded or installed without the user's yes + https + allow-listed host + exact SHA-256 + exact size. No silent APK install; no downgrade.
- Skills/shortcuts are data only and may contain only built-in safe commands. NOVA never rewrites its own code on the phone.
- API keys never appear in logs, URLs, the repo, or the UI.
