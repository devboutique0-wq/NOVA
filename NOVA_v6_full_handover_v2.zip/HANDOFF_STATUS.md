# NOVA handoff status (updated 2026-10-09)

Everything below was written in a sandbox WITHOUT a Kotlin compiler, Android SDK or network.
**Build: NOT RUN. Unit tests: NOT RUN. Phone: NOT TESTED.** Status ladder: STATICALLY VERIFIED at best.
Python tooling (tools/test_self_improve.py, tools/build_feed.py offline part) WAS run here: LOCAL RUNTIME VERIFIED for those scripts only.

Built (code written, never compiled):
- Original NOVA 6.0, Step 1 floating card (NovaHud), Step 2 screen control (Control, NovaAccessibilityService),
  Step 3 Layer-1 brain (Brain, BrainStore), Step 4 Discover-Ask-Add updater (Updater, UpdateManager, InstallReceiver).
- A (partly): static review of the 5 suspicious spots. Only one change was made: BrainStore lambdas now have explicit `: Unit`.
  The real "build green" still needs a GitHub run.
- B: app/build.gradle.kts signing via env vars (NOVA_KEYSTORE_PATH/PASSWORD, NOVA_KEY_ALIAS/PASSWORD, NOVA_VERSION_CODE);
  build.yml loads secrets; make-keystore.yml creates the key once; release.yml publishes nova-vc<N>.apk.
- C: tools/build_feed.py + feed.yml (skills from skillpacks/, newest release apk, models from tools/models.json via Hugging Face);
  skillpacks/starter.json. tools/models.json is EMPTY (no model chosen yet).
- D: tools/self_improve.py + self-improve.yml (PR only, protected paths, max 3 files, tests must pass);
  SafetyInvariantsTest.kt; tools/test_self_improve.py (also run in build.yml).
- E: LocalBrain.kt (interface + prompt + strict output parser), LocalBrains.kt (slot, 8 s timeout), hook in NovaService.handle()
  after brain.resolve and before the cloud. A model suggestion of "tap" always asks a spoken yes. NO inference engine yet
  (LocalBrains.factory is null, so behaviour is unchanged). LocalBrainTest.kt written.

Next action: follow SETUP_STEPS.md step 1, run "Build and Test APK", fix whatever the log reports.
