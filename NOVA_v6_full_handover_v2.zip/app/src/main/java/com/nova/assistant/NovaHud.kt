package com.nova.assistant

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.provider.Settings
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import java.util.Random

/**
 * Pure drawing logic for the "transformer" card. No Android window code here, so it is easy to reason about.
 * 12 steel plates fly in from random directions, spinning, and snap together into one card; the text appears
 * after they have joined. Reverse for hiding.
 */
internal object HudMath {
    const val COLS = 4
    const val ROWS = 3
    const val PANELS = COLS * ROWS

    /** Per-plate progress 0..1 for global time t (0..1). Plates start staggered, each takes 55% of the timeline. */
    fun plateProgress(index: Int, t: Float): Float {
        val delay = index * 0.035f
        val p = (t - delay) / 0.55f
        return if (p < 0f) 0f else if (p > 1f) 1f else p
    }

    /** easeOutBack: slight overshoot, which reads as the plate "clicking" into place. */
    fun easeOutBack(x: Float): Float {
        val c1 = 1.70158f
        val c3 = c1 + 1f
        val u = x - 1f
        return 1f + c3 * u * u * u + c1 * u * u
    }

    /** Text becomes visible only after the plates joined (t from 0.75 to 1.0). */
    fun textAlpha(t: Float): Float {
        val a = (t - 0.75f) / 0.25f
        return if (a < 0f) 0f else if (a > 1f) 1f else a
    }
}

/**
 * Floating NOVA card shown over every app (needs the "Display over other apps" permission).
 * All methods must be called on the main thread. If the permission is missing everything is a silent no-op,
 * so voice commands keep working exactly as before.
 */
class NovaHud(private val ctx: Context) {

    private val wm: WindowManager = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var view: HudView? = null
    private var shownAt = 0L

    companion object {
        fun canShow(ctx: Context): Boolean = Settings.canDrawOverlays(ctx)
        const val MIN_VISIBLE_MS = 2500L
    }

    val isShown: Boolean get() = view != null
    fun visibleForMs(): Long = if (view == null) 0L else System.currentTimeMillis() - shownAt

    /** state: "listen", "think", "reply". */
    fun show(state: String) {
        if (!canShow(ctx)) return
        val v = view
        if (v != null) { v.setState(state); return }
        val nv = HudView(ctx)
        nv.setState(state)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = (72 * ctx.resources.displayMetrics.density).toInt()
        try {
            wm.addView(nv, lp)
            view = nv
            shownAt = System.currentTimeMillis()
            nv.onDismissTap = { hide() }
            nv.assemble()
        } catch (e: Exception) {
            view = null     // no overlay allowed right now: keep running without the card
        }
    }

    fun setHeard(text: String) { view?.heard = text; view?.invalidate() }
    fun setReply(text: String) { view?.reply = text; view?.invalidate() }
    fun setState(state: String) { view?.setState(state) }

    /** Plates fly apart, then the window is removed. */
    fun hide() {
        val v = view ?: return
        view = null
        v.disassemble { try { wm.removeView(v) } catch (e: Exception) { } }
    }

    /** Immediate removal (service stopping). */
    fun destroy() {
        val v = view ?: return
        view = null
        v.cancelAnim()
        try { wm.removeView(v) } catch (e: Exception) { }
    }
}

private class HudView(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val cardW = (minOf(ctx.resources.displayMetrics.widthPixels - 40 * d, 340 * d)).toInt()
    private val cardH = (176 * d).toInt()

    var heard = ""
    var reply = ""
    var state = "listen"
    var onDismissTap: (() -> Unit)? = null

    private var t = 0f                     // 0 = scattered, 1 = assembled
    private var anim: ValueAnimator? = null
    private var pulse = 0f

    private val rnd = Random(7L)
    private val fromX = FloatArray(HudMath.PANELS)
    private val fromY = FloatArray(HudMath.PANELS)
    private val fromRot = FloatArray(HudMath.PANELS)

    private val plate = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.5f * d; color = 0xFF27E1FF.toInt() }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f * d; color = 0xFF27E1FF.toInt() }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF27E1FF.toInt() }
    private val head = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF27E1FF.toInt(); textSize = 12f * d; typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        letterSpacing = 0.15f
    }
    private val small = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF8FA3B5.toInt(); textSize = 12f * d }
    private val big = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFEAF6FF.toInt(); textSize = 15f * d }
    private val rect = RectF()

    init {
        for (i in 0 until HudMath.PANELS) {
            val ang = rnd.nextFloat() * (2.0 * Math.PI).toFloat()
            val dist = (220f + rnd.nextFloat() * 260f) * d
            fromX[i] = Math.cos(ang.toDouble()).toFloat() * dist
            fromY[i] = Math.sin(ang.toDouble()).toFloat() * dist
            fromRot[i] = (rnd.nextFloat() - 0.5f) * 540f
        }
        setOnClickListener { onDismissTap?.invoke() }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(cardW, cardH)
    }

    fun setState(s: String) { state = s; invalidate() }

    fun assemble() { run(0f, 1f, 650L, null) }
    fun disassemble(end: () -> Unit) { run(t, 0f, 420L, end) }
    fun cancelAnim() { anim?.cancel(); anim = null }

    private fun run(from: Float, to: Float, ms: Long, end: (() -> Unit)?) {
        anim?.cancel()
        val a = ValueAnimator.ofFloat(from, to)
        a.duration = ms
        a.interpolator = LinearInterpolator()
        a.addUpdateListener { t = it.animatedValue as Float; invalidate() }
        a.addListener(object : android.animation.AnimatorListenerAdapter() {
            private var cancelled = false
            override fun onAnimationCancel(animation: android.animation.Animator) { cancelled = true }
            override fun onAnimationEnd(animation: android.animation.Animator) {
                if (cancelled) return          // a newer animation replaced this one
                if (end != null) end()
                else startPulse()
            }
        })
        anim = a
        a.start()
    }

    private fun startPulse() {
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 1100L
        a.repeatCount = ValueAnimator.INFINITE
        a.repeatMode = ValueAnimator.REVERSE
        a.addUpdateListener { pulse = it.animatedValue as Float; invalidate() }
        anim = a
        a.start()
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        anim = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val w = cardW.toFloat()
        val h = cardH.toFloat()
        val gap = 2f * d
        val pw = w / HudMath.COLS
        val ph = h / HudMath.ROWS
        for (i in 0 until HudMath.PANELS) {
            val col = i % HudMath.COLS
            val row = i / HudMath.COLS
            val p = HudMath.plateProgress(i, t)
            val e = HudMath.easeOutBack(p)
            val cx = col * pw + pw / 2f
            val cy = row * ph + ph / 2f
            val k = 1f - e
            c.save()
            c.translate(cx + fromX[i] * k, cy + fromY[i] * k)
            c.rotate(fromRot[i] * k)
            val s = 0.35f + 0.65f * minOf(e, 1f)
            c.scale(s, s)
            plate.shader = LinearGradient(
                -pw / 2f, -ph / 2f, pw / 2f, ph / 2f,
                0xFF222E3B.toInt(), 0xFF0B1118.toInt(), Shader.TileMode.CLAMP
            )
            plate.alpha = (255 * minOf(1f, p * 2.5f)).toInt()
            rect.set(-pw / 2f + gap, -ph / 2f + gap, pw / 2f - gap, ph / 2f - gap)
            c.drawRoundRect(rect, 5f * d, 5f * d, plate)
            edge.alpha = (200 * minOf(1f, p * 2.5f)).toInt()
            c.drawRoundRect(rect, 5f * d, 5f * d, edge)
            c.restore()
        }

        val ta = HudMath.textAlpha(t)
        if (ta <= 0f) return
        // glowing frame once joined
        glow.alpha = ((60 + 90 * pulse) * ta).toInt().coerceIn(0, 255)
        rect.set(1.5f * d, 1.5f * d, w - 1.5f * d, h - 1.5f * d)
        c.drawRoundRect(rect, 8f * d, 8f * d, glow)

        val pad = 16f * d
        val label = when (state) {
            "listen" -> "N O V A  //  LISTENING"
            "think" -> "N O V A  //  THINKING"
            else -> "N O V A"
        }
        dot.alpha = (ta * (140 + 115 * pulse)).toInt().coerceIn(0, 255)
        c.drawCircle(pad + 4f * d, pad + 5f * d, 4f * d, dot)
        head.alpha = (255 * ta).toInt()
        c.drawText(label, pad + 16f * d, pad + 9f * d, head)

        var y = pad + 26f * d
        if (heard.isNotBlank()) {
            small.alpha = (255 * ta).toInt()
            c.drawText(TextUtils.ellipsize(heard, small, w - 2 * pad, TextUtils.TruncateAt.END).toString(), pad, y + 10f * d, small)
        }
        y += 22f * d
        val body = if (reply.isNotBlank()) reply else if (state == "listen") "Bolo, main sun raha hoon..." else "..."
        big.alpha = (255 * ta).toInt()
        val lay = build(body, big, (w - 2 * pad).toInt(), 4)
        c.save()
        c.translate(pad, y)
        lay.draw(c)
        c.restore()
    }

    private fun build(text: String, paint: TextPaint, width: Int, maxLines: Int): StaticLayout {
        return StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setEllipsize(TextUtils.TruncateAt.END)
            .setMaxLines(maxLines)
            .build()
    }
}
