# NOVA handoff status (updated 2026-10-09)

Everything below was written in a sandbox WITHOUT a Kotlin compiler, Android SDK or network.
**Build: NOT RUN. Unit tests: NOT RUN. Phone: NOT TESTED.** Status ladder: STATICALLY VERIFIED at best.
Python tooling (tools/test_self_improve.py, tools/build_feed.py offline part) WAS run here: LOCAL RUNTIME VERIFIED for those scripts only.

Built (code written, never compiled):
- Original NOVA 6.0, Step 1 floating card (NovaHud), Step 2 screen control (Control, NovaAccessibilityService),
  Step 3 Layer-1 brain (Brain, BrainStore), Step 4 Discover-Ask-Add updater (Updater, UpdateManager, InstallReceiver).
- A (partly): static review of the 5 suspicious spots. Only one change was made: BrainStore lambdas now have explicit `: Unit`.
  The real "build green" still needs a GitHub run.
- B: app/build.gradle.kts signing via env vars (NOVA_KEYSTORE_PATH/PASSWORD, NOVA_KEY_ALIAS/PASSWORD, NOVA_VERSION_CODE);
  build.yml loads secrets; make-keystore.yml creates the key once; release.yml publishes nova-vc<N>.apk.
- C: tools/build_feed.py + feed.yml (skills from skillpacks/, newest release apk, models from tools/models.json via Hugging Face);
  skillpacks/starter.json. tools/models.json is EMPTY (no model chosen yet).
- D: tools/self_improve.py + self-improve.yml (PR only, protected paths, max 3 files, tests must pass);
  SafetyInvariantsTest.kt; tools/test_self_improve.py (also run in build.yml).
- E: LocalBrain.kt (interface + prompt + strict output parser), LocalBrains.kt (slot, 8 s timeout), hook in NovaService.handle()
  after brain.resolve and before the cloud. A model suggestion of "tap" always asks a spoken yes. NO inference engine yet
  (LocalBrains.factory is null, so behaviour is unchanged). LocalBrainTest.kt written.

Next action: follow SETUP_STEPS.md step 1, run "Build and Test APK", fix whatever the log reports.

## Feature 6: Driving mode (added 2026-10-09, code written, NEVER compiled or run)
Files: Driving.kt (pure rules), NovaNotificationService.kt (NotificationListenerService + DrivingBridge), manifest service entry,
Logic.classify hook (Driving.command), NovaService (onDrivingMessage, driveOn/Off/Read/Clear/Reply, runCommand branches), DrivingTest.kt,
SafetyInvariantsTest extended.
Behaviour: voice "driving mode on" (needs Notification access switched on by the user in Android settings; NOVA opens that screen).
New messages from WhatsApp / WhatsApp Business / Telegram / Messages are read aloud. Voice "read messages", "clear messages",
"reply driving|busy|okay|thanks|later" -> NOVA says the exact fixed text and sends it through the notification's own Reply button ONLY after a
spoken local "yes" (askFirst). Messages with codes/OTP/password words are never read. Text stays in memory only (last 8), is never logged or
uploaded, and is wiped on "driving mode off" and when the service stops. Driving mode is OFF after every restart. drive_* kinds are NOT in
Brain.SAFE_KINDS, so shortcuts and the offline model can never trigger them.
Not built: free dictation of a reply (needs a capture-next-utterance mode in NovaService), an on/off button in ui.html, other apps.
Status: STATICALLY VERIFIED at best. Check first if the build fails: NovaNotificationService.kt (Notification.Action / RemoteInput calls),
the new NovaService methods, DrivingTest expectations against Logic.classify.

## Feature 10: blue Transformer UI v2 (2026-10-09, browser-tested only, NEVER compiled for Android or run on a phone)
ui.html rebuilt: full-screen canvas pod (10 plates incl. wings, bevels, rivets, light strips, sheen) assembles -> opens -> core boots -> dashboard;
synthesized sound (WebAudio, no files) + phone vibration (Android.vibrate); close/standby sequence (power button or Back); metal doors for Settings;
feature cards open a clickable sheet; globe dashboard + decorative voice waveform (NOT the real mic level) + greeting card.
Kotlin changes (check first if the build fails): MainActivity.kt -> hardenWebView (mediaPlaybackRequiresUserGesture, domStorageEnabled),
onBackPressed() (calls novaBack() in the page, moveTaskToBack on 'exit'), vibe() + Bridge.vibrate(); AndroidManifest.xml -> VIBRATE permission.
Status: LOCAL RUNTIME VERIFIED for ui.html in headless Chromium only. TARGET PHONE VERIFIED needed (sound, vibration, Back button, animation speed).

## Feature 11: floating wake card in pod style (2026-10-09, code written, NEVER compiled)
NovaHud.kt: metallic plates with inner panel / light strip / rivets, seam flare (HudMath.seamFlare + test), core badge with spinning arcs,
blue waveform, one vibration tick when a new reply appears. No wake-time sound/vibration on purpose (mic would hear it). Needs overlay permission.
Handover prompt for the next chat: NEXT_ACCOUNT_HANDOVER_PROMPT_v7.md. Next action is still: run "Build and Test APK" and fix the log.

## Feature 12: sleep-by-default + Update Center (2026-10-09, code written, NEVER compiled; ui.html tested in headless Chrome with a MOCK bridge only)
User asked: NOVA must be active only after the wake word, do the task, then go back to sleep (nothing unnecessary); and after app launch a section
that shows what was updated / what is to be done, asks permission and does it there.
Sleep (NovaService.kt): new mode "sleep". After every turn finishTurn() -> armSleep(card hold + 0.6 s) -> goSleep(): waits while busy/listening/speaking/
a yes is pending, then clears chat memory + last command, hides the card, sends mode "sleep" (UI dims, status "Sleep mode - 'nova' bolo to jaagunga").
"Heard nothing" after a wake also sleeps after 2.5 s. startCapture() cancels the sleep timer. Service start now begins in "sleep".
withNudge ("shortcut bana du?") is now OFF by default (Cfg.nudges) because it opened the mic by itself after commands.
Update Center (ui.html + MainActivity bridge getStatus / requestBasics / openNotificationAccess; "resumed" flow event from onResume):
opens by itself ONCE per launch after the intro only if: new version not yet seen, mic/notification permission missing, or a new update offer exists.
Shows: what is new (CHANGES array in ui.html - edit it every release), permission list with ALLOW buttons, offers with INSTALL/SKIP, and one big
"next step" button (first missing must-have permission -> install permission -> install first offer -> set feed URL -> check). Also reachable from the Safe Updates card.
Nothing installs without the user's tap; the existing Updater safety checks (https, host list, SHA-256, size, same signature) are unchanged.
FOUND + FIXED in CI: build.yml ui.html syntax check used a greedy regex over TWO script blocks (would have failed); now checks each block.
FOUND + FIXED: `catch (_: Throwable)` in MainActivity.kt (vibe) and NovaHud.kt would have been rejected by the build.yml "catch (_" guard.
If the build fails here, check first: NovaService.goSleep/armSleep, MainActivity.getStatus (canRequestPackageInstalls, DrivingBridge.listenerEnabled), REQ_BASIC.
Status: STATICALLY VERIFIED at best. Phone test needed: does NOVA still wake reliably, does the card hide, does the Update Center open once and the ALLOW buttons work.

## Feature 13: default assistant option (2026-10-09, code written, NEVER compiled or run)
NovaAssist.kt (NovaInteractionService, NovaSessionService/NovaSession, NovaRecognitionStub), res/xml/voice_interaction.xml, 3 manifest service entries,
NovaService.wakeNow() + wakeRequest (audio loop starts a capture like the wake word), MainActivity: getStatus "assistant", openAssistantSettings(), isDefaultAssistant().
Update Center row "Default assistant" opens Android's Digital assistant app screen; the user must pick NOVA there (an app cannot set it by itself).
NOVA does not use screen/assist data from this door. If the build fails, check first: NovaAssist.kt (VoiceInteractionSession ctor, RecognitionService.Callback override signatures).
Phone check needed: does NOVA appear in the assistant list, does long-press Home/power wake it.

## Autopsy v8 (2026-10-10) - 4 fixes written, pure-Kotlin part COMPILED + TESTED here, Android part NOT compiled
Verified in the sandbox with kotlin-compiler-embeddable 2.0.21 + JUnit: Logic, Brain, Control, Driving, HindiRoman, LocalBrain, Updater and 8 test classes
= 116 tests, all green (incl. new ListenTest.kt). ui.html: node --check passed (5 script blocks). CI guards (`!!`, `catch (_`) clean.
NOT compiled here (no Android SDK): NovaService.kt, MainActivity.kt, HealthCheck.kt. Check these first if the GitHub build is red.
1. Smart end of speech: Logic.fastEndMs + NovaService.audioLoop (`fastDone`). A complete simple command now runs after ~1.2 s of silence
   (open_app ~1.8 s) instead of the 5 s wait. Not used for yes/no answers, dictated replies, typing, taps. The user's wait setting still applies to everything else.
2. Custom wake word: Logic.setWake()/stripWake()/classify now strip the chosen wake word (and "nova") from the start of a command.
3. Voice "unlock phone": Logic kind "unlock" -> NovaService.unlockPhone() -> PatternUnlock.run. Works only if UNLOCK ON in the NOVA Pattern screen
   and Accessibility is on. NOT in Brain.SAFE_KINDS (a shortcut / offline model can never unlock). Anyone who says the wake word can unlock: user's choice.
4. Battery: new Update Center row "Battery: No restrictions" (Bridge.openBatterySettings, status key "battery", REQUEST_IGNORE_BATTERY_OPTIMIZATIONS),
   and HealthCheck now treats it as important.
Phone test needed: say "nova torch on" - reaction in ~1.5 s; "nova go home"; custom wake word + "open youtube"; "nova unlock phone" with phone locked.
Still open (needs a phone/CI test, see NEXT_ACCOUNT_PROMPT_v8.md): Hindi listening model, unused model-en-in, Hindi yes/no.

## v9 (2026-10-10) - listening quality, part B(a)
- NovaService: command recognizer `cm` now uses assets/model-en-in (Indian English) via loadCommandModel(); wake recognizer `wk`, resolveWake and words.txt stay on model-en.
  Any failure while loading model-en-in (missing asset, corrupt copy, native error) -> returns null and `cm` falls back to model-en. model is closed in finally.
- Verification: sandbox compile + 116 JUnit tests OK (pure logic unchanged). NovaService change = STATICALLY CHECKED ONLY (no `!!`, no `catch (_`); GitHub build NOT RUN yet; NOT phone tested.
- Risk to check on phone: RAM (two Vosk models loaded), start-up time, and whether commands are recognised better than before. If the app crashes on ACTIVATE, revert this one change.

## v9b (2026-10-10) - glass popup, app theme, strict wake
- NovaHud.kt: new "holographic glass" card (glowing orb, state colours, waveform, reply text, pop-in/out). Public API unchanged. HudMath maths = JUnit tested (sandbox). Drawing code = NOT phone tested.
- ui.html: added <style id="theme-v2"> (colours/shapes only, no ids/scripts changed). node --check OK on all 6 script blocks; headless-Chromium screenshot checked. Note: JS overwrites #app className, so CSS must use #app, not .wrap.
- Strict wake: Logic.nextWakeHits/wakeConfirmed (wake word must repeat in 2 consecutive results unless it is a final result) + Logic.isFalseWake (nothing heard, or noise only in offline mode -> silent sleep, no spoken error, no card). Gates kept: loudness gate, 1.5 s cooldown. Yes/no answers and dictation unchanged.
- Verification: sandbox 122 JUnit tests OK (116 + 6 new) + 12 HUD tests OK. GitHub build NOT RUN. Phone test NOT DONE. Check: false wakes with TV/noise, normal "nova torch on" still wakes first time, card look on a real phone.

## v15b (2026-10-10) - Layer 0 offline skills (6B step 1)
- NEW LocalSkills.kt (pure Kotlin): calculator (plus/minus/times/divided by/percent of/square/root, digits or spelled numbers incl. lakh/crore/point), unit conversion (length, mass, volume incl. cup/tbsp/tsp, C<->F), date maths ("45 din baad kya tarikh", "10 days ago", weekday of today/tomorrow), emergency numbers India (112/100/101/102/108/1091/1098/1930), first aid text for burn / nosebleed / bleeding / snake bite (general info, always "doctor/112", no dosing).
- Routing: NovaService.handle() calls LocalSkills.answer() FIRST (before Logic.classify). Every skill is strict (numbers must parse fully, units known, topic known) so it returns null and normal routing continues for anything else. It only produces text, never acts on the phone.
- Not done yet from step 1: timers/alarms/reminders (needs AlarmManager + exact-alarm OK), local notes/to-do list, festival/holiday list, contacts lookup. Chains like "5 plus 6 plus 7" are not supported on purpose.
- Verification: sandbox compile + 136 JUnit tests OK (122 old + 14 LocalSkillsTest). node --check OK on 6 script blocks. `!!` and `catch (_` guards clean. NovaService change = STATICALLY CHECKED only. GitHub build NOT RUN. Phone NOT TESTED.
- Phone test phrases: "nova fifteen percent of two hundred", "nova 5 kg to pounds", "nova forty five din baad kya tarikh", "nova police number", "nova first aid for burn", and check "nova torch on" / "volume fifty" still work.

## v15c (2026-10-10) - offline timer / reminder / alarm (6B Layer 0, part 2)
- FOUND: timer/alarm existed only as Gemini tools (cloud), so they did not work offline. NEW Timers.kt (pure): "timer" (seconds), "alarm" (minute of day), "alarm_any" (no am/pm said: next matching time, resolved at run time). Reminder = timer whose label is the thing to remember. Hooked in Logic.classify (before Driving) and NovaService.runLocalTool -> existing timerTool/alarmTool (AlarmClock intents: the system Clock app rings, works while NOVA sleeps, no exact-alarm permission). Replies now say the real duration / clock time. Android gives no confirmation: the reply says so.
- Not supported on purpose: cancel/delete alarm (no safe Android API), chains, timer > 24 h, reminders without a duration ("remind me at 5" = use alarm).
- Two old LogicTest asserts changed on purpose (they expected timer/alarm to go to the cloud).
- Verification: sandbox 144 JUnit tests OK (136 + 8 TimersTest). Guards clean, node --check OK. NovaService edit STATICALLY CHECKED only. GitHub build NOT RUN, phone NOT TESTED.
- Phone test: "nova set timer for five minutes", "nova do minute ka timer laga do", "nova das minute baad chai yaad dilao", "nova set alarm for six thirty am", "nova alarm laga do six baje" (check Clock app for each; misheard numbers are possible, read the reply).

## v16 (2026-10-10) - offline AI infrastructure, PURE parts only (Android wiring NOT done)
Verified in sandbox: 166 JUnit tests OK (compile list: Logic Brain Control Driving HindiRoman LocalBrain Updater LocalSkills Timers ModelDownload ModelCatalog LocalChat + 14 test classes). No Android file was edited in v16 except Updater.kt (pure). GitHub build NOT RUN, phone NOT TESTED.
NEW pure files (all unit tested, NOT yet called from the app):
- ModelDownload.kt: resumable (Range) + verified (size, SHA-256) + redirect-checked download. Tested against a local HTTP server: full, redirect, interrupted+resume, server ignores Range, wrong hash (file deleted), too big (deleted), low storage (refused before any request), blocked host, 404, cancel+resume, oversized/complete .part.
- ModelCatalog.kt: ITEM = Qwen2.5-0.5B-Instruct Q4_K_M, official repo Qwen/Qwen2.5-0.5B-Instruct-GGUF, licence apache-2.0, size 491400032, sha256 74a4da8c9fdbcd15bd1f6d01d621410d31c6fc00986f5eb687824e7b93d7a9db (read twice from the HF git-lfs pointer through WebFetch; if a download ever fails with "checksum mismatch" re-check this value first, the app fails safe), MIN_TOTAL_RAM_MB 3000.
- LocalChat.kt: ChatML prompt (Qwen format) with persona, output cleaner (template/markdown/loop/length), preAnswer (live-info questions never guessed; crisis words get a fixed safe answer with 112 + Tele-MANAS 14416), guard (health/money/legal safety line). AiRouter: plan(cloudConfigured, cloudCooling, localReady, text) = cloud first for real questions, local first for small talk, cooldownMs per failure kind.
- Updater.hostAllowed now also accepts *.hf.co and *.huggingface.co (HF changes CDN hosts; SHA pin protects content).
Owner's master prompt saved as OWNER_MASTER_UPGRADE_PROMPT.md. See NEXT_ACCOUNT_PROMPT_v12_FULL.md for the exact remaining steps.

## v16b (2026-10-10) - STEP 1 wiring: model download + offline-brain routing (no engine yet)
- UpdateManager.doInstall: type "model" now uses ModelDownload.download (resumable, SHA-256 + size, host allow-list, free-space check). A stopped download keeps the .part file ("Tap again to resume"); checksum/size failures delete it. skills/apk keep the old loop. refresh() keeps the built-in offer.
- UpdateManager.offerOfflineBrain(ctx) validates ModelCatalog.ITEM and adds it to the offers (nothing downloads until the user taps). Bridge: offerOfflineBrain(); getStatus adds engine, ramMb, ramOk, brainInstalled.
- ui.html Update Center: new section OFFLINE BRAIN. Download button only if engine present AND ramOk; otherwise it says why. HATAO = rollbackUpdate (deletes the model). Built-in model is hidden from the normal UPDATES list and from auto-open.
- LocalBrain.close() default; LocalBrains: available(), release(), single busy flag (second request refused), chat() = LocalChat prompt + clean + guard. NovaService.onTrimMemory(>= RUNNING_LOW) and onDestroy release the model.
- NovaService.handle: junk never reaches any model (also not the translator). Order via AiRouter.plan + new pure Routing.run: cloud failure -> cooldown (AiRouter.cooldownMs) -> local chat; if a cloud tool already acted, no local answer is added; local answer is TEXT ONLY, prefixed "Offline:". No source -> the old honest local-mode message.
- Tests: RoutingTest (9 cases). NOT RUN: this sandbox had no Kotlin compiler.
- Verification level: STATICALLY CHECKED only (re-read, brace balance, `!!` / `catch (_` guards clean, node --check OK on 6 script blocks). Unit tests NOT executed. GitHub build NOT RUN. Phone NOT TESTED.
- Engine still missing (LocalBrains.factory == null) so the download button stays hidden today. Next: STEP 2 (one Gradle dependency + LlamaBrain.kt).

## v16c (2026-10-10) - one launcher icon
- Owner saw 2 NOVA icons: PatternSetupActivity had its own LAUNCHER filter. Removed it (exported=false). New Bridge.openPatternSetup() + Update Center row "Pattern unlock setup" (status key "pattern" = PatternUnlock.isSet).
- Verification: node --check OK on 6 script blocks, `!!` / `catch (_` guards clean. Kotlin NOT compiled here, GitHub build NOT RUN for this change, phone NOT TESTED.
- Owner also reported: app loads, "gets stuck at the pattern stage but the pattern itself works" - not yet understood, asked the owner what exactly freezes.

## v17 (2026-10-10) - autopsy: real offline engine + two "stuck" bugs (Kotlin NOT compiled here, GitHub build NOT RUN, phone NOT TESTED)
FOUND (fake / dead):
1. Offline AI was a facade: LocalBrains.factory was null, so the OFFLINE BRAIN download button never showed and "Offline:" answers never happened. FIXED (written, not compiled): NEW LlamaBrain.kt (llama.cpp via io.github.ljcamargo:llamacpp-kotlin:0.4.0; calls copied from the library's demo MainViewModel.kt: LlamaHelper(contentResolver, scope, sharedFlow), load(path, contextLength){}, predict, stopPrediction, abort, release, events Ongoing/Done/Error). LocalBrains.installEngine(ctx) is called from NovaService.onCreate and MainActivity.onCreate. build.gradle.kts: that dependency + kotlinx-coroutines-core 1.8.1 + abiFilters arm64-v8a only.
2. Mic/Notification ALLOW button became dead after Android's "don't ask again": Update Center's big button kept pointing at it = looked stuck. FIXED: Bridge.requestBasics opens the app's settings page in that case (returns "settings", ui shows a note).
3. Update Center's big button said "UPDATE FEED URL DALO" forever when no feed is set (feed is optional). FIXED: it now says "SAB TAIYAAR - BAND KARO" and closes.
UNVERIFIED RISKS (check first if the build is red): (a) LlamaHelper member names/types come from the library's master-branch demo, not from the 0.4.0 AAR; (b) the AAR's minSdk could be above 26; (c) licence: README says MIT, Maven POM says Apache-2.0 (both permissive); (d) native code from a one-person project ships in the APK; (e) sampling settings are not exposed by the library. If red: delete LlamaBrain.kt, the 2 dependency lines and the installEngine calls = back to v16c behaviour.
Phone test: Update Center > OFFLINE BRAIN > DOWNLOAD (Wi-Fi, 491 MB) > "nova hello" > Wi-Fi off > "nova why is the sky blue" (note latency, heat). Permissions: deny mic twice, then tap ALLOW again = Settings page should open.

## v17b (2026-10-10) - lighting + open animations (owner request)
- ui.html: new <style id="lights-v1"> + #lt/#flash/#shock layers + lights(t) driven from the existing intro frame loop (beams, halo, anamorphic flare, white-cyan flash and shock ring at the reveal, intro fade 0.5s -> 0.2s), app "slam" entrance, light sweep, spring+glow popups (.ucb, .sh, #chat). All under prefers-reduced-motion:no-preference. Checked in headless Chromium with a mock bridge: no JS errors, frames look right. NOT phone tested (real GPU speed unknown; if janky remove .bm blur filters first).
- NovaHud.kt: HudMath.springEase / entryFlash (+3 tests in HudMotionTest.kt, maths checked in Python: peak 1.18, end 1.002), card opens in 560 ms with slide + spring, border flash, light sweep, shock ring (only while opening). Kotlin NOT compiled.

## v18a (2026-10-10) - Part 1A: free AI provider chain, PURE CORE only (Kotlin NOT compiled here, tests NOT run)
This sandbox had no kotlinc and no network. Status: STATICALLY CHECKED only (brace/paren balance with a real tokenizer, no `!!`, no `catch (_`, no TODO, no name clash).
NEW: app/src/main/java/com/nova/assistant/FreeProviders.kt (pure, no Android, no org.json):
- MiniJson (quote + strict parser, never throws, depth limit 40), FreeProvider, NetAnswer(code, body) [598 = no internet, 599 = timeout/IO], ChainResult, Cooldowns (clock passed in).
- FreeProviders: GROQ (llama-3.3-70b-versatile, llama-3.1-8b-instant), OPENROUTER (two ":free" models), POLLINATIONS (https://text.pollinations.ai/openai, no key); systemPrompt(en), buildBody, parseReply (choices[0].message.content; a 200 with an "error" body = failure), clean (no <think>, no markdown, cap 700 chars on a sentence end), kindOf, cooldownFor (key 10 min, quota 2 min, server 30 s, network 15 s, model 60 s, other 20 s), failText (honest Hindi/English).
- ProviderChain.run(providers, keyOf, enabled, system, user, cooldowns, now, budgetMs=14000, call): skip disabled / cooling / keyless-needed providers with NO call; 429/400/404/422 -> next model; 401/403/5xx/timeout -> next provider; 598 -> stop whole chain; useless 200 body = failure; budget stops the chain.
- NEW test: FreeProvidersTest.kt (28 tests). Written, NOT executed.
UNVERIFIED (check first if CI is red): (a) the three endpoint URLs and the model ids were written from public OpenAI-compatible docs and could not be called from here; free model ids change, the chain moves on by itself on 404/400; (b) Kotlin compile of FreeProviders.kt (`'\b'` char literal, `while`+`fail()` ending in Nothing-returning functions, `break` inside `when`-free loops) - if the compiler complains, fix that line only.
NOT DONE (this is part 1B): real HTTP caller (HttpURLConnection, returns 598/599, never throws), key slots in SecureStore + Settings UI (Groq key already exists via SecureStore.getGroq; OpenRouter needs a slot), NovaService wiring, crisis/live-info preAnswer + LocalChat.guard on the chain's answers, AiRouter.plan change (cloud is no longer "configured only with a Gemini key": Pollinations needs none), per-provider on/off, a Python mock-server run of the failover. Nothing in the running app calls the chain yet, so app behaviour is unchanged.
Privacy note: the chain sends ONLY the user's spoken/typed question to these third-party services. Screen text, notifications, memory and contacts must never be sent.
Next action: see NEXT_ACCOUNT_PROMPT_v18_PART1B.md.

## v18b (2026-10-10) - Part 1B: free AI chain WIRED into the app (Kotlin NOT compiled here, unit tests NOT run)
Sandbox again had no kotlinc and no network. Verified HERE: bracket balance (real tokenizer) of FreeProviders/FreeHttp/ExtCfg/MainActivity/NovaService/test; no `!!` / `catch (_` / TODO in any file I touched; ui.html node --check OK (6 blocks); tools/test_chain_contract.py ALL PASSED (24 checks, real HTTP sockets, see below); old tools/test_self_improve.py OK. NOT verified: Kotlin compile, the 37 FreeProvidersTest tests, phone.
Changes:
- NEW FreeHttp.kt: HTTPS-only POST, no redirects, connect 6 s / read 10 s, body cap 200 KB, UnknownHost/Connect -> 598, any other error -> 599, never throws, never logs key/question/answer. OpenRouter gets HTTP-Referer + X-Title.
- ExtCfg: freeChain (default ON), freeKeyless (default ON). MainActivity Bridge: saveOpenRouterKey / hasOpenRouterKey / clearOpenRouterKey (SecureStore slot "openrouter", never sent back to the page), get/setFreeChain, get/setFreeKeyless. ui.html: new box "FREE ONLINE AI" (two switches + OpenRouter key). Groq key = the existing speech key.
- FreeProviders.kt (pure) gained: canUseChain, chainPreAnswer (crisis words -> fixed 112 + Tele-MANAS answer, NEVER sent online; live-data words -> honest "no live source" - LocalChat.preAnswer says "offline", which would be false when online), combinedFailure (no-internet beats everything, then Gemini's own message, then the chain's).
- NovaService.cloudStep now = Gemini (own cooldown geminiCoolUntil) -> free chain (shared Cooldowns) -> combinedFailure. plan() gets (geminiKey || freeChain). Chain answer passes LocalChat.guard, lastKind="free_chain", text only, never an action. Gemini that already ran a tool is never followed by the chain.
- 9 more tests in FreeProvidersTest (37 total).
BEHAVIOUR CHANGE to check on the phone: with the default switch ON, a question NOVA cannot answer locally now goes online (Pollinations needs no key) even with no Gemini key. Only the spoken question is sent. Turn off in Settings > FREE ONLINE AI.
KNOWN LIMITS: (1) Logic.norm keeps only a-z0-9, so a Devanagari-only text counts as "junk" and never reaches the chain; fix in part 4 (Hindi). (2) Free model ids / endpoints could not be called from this sandbox: if a provider 404s the chain moves on, but confirm each on a phone with real keys. (3) tools/test_chain_contract.py checks a Python PORT of the rules plus the Kotlin SOURCE TEXT; it is not a run of the Kotlin code. (4) build.yml is not in this zip: add `python3 tools/test_chain_contract.py` next to test_self_improve.py when the workflow is available.
Phone test: Settings > FREE ONLINE AI; say "nova why is the sky blue" with Wi-Fi on and NO keys (Pollinations should answer), then add a Groq key and repeat, then airplane mode (expect the honest "no internet" text or the offline model), "nova weather today" (honest no-live-source text), "nova torch on" (still instant, offline).

## v18c (2026-10-10) - Part 1 reviewed by a second account (static review + 2 factual fixes; Kotlin still NOT compiled, tests NOT run)
Checked here: python3 tools/test_chain_contract.py ALL PASSED; tools/test_self_improve.py OK; ui.html node --check OK (6 blocks); tokenizer bracket balance over every .kt file OK; no `!!` / `catch (_` / TODO in the files Part 1 touched; NovaService/ExtCfg diff against the v15 zip read line by line (logic: Gemini first, own cooldown; chain only after a Gemini failure without a tool run; crisis words never leave the phone; chain answer goes through LocalChat.guard; text only).
FIXED (found by reading current provider docs): (1) Pollinations text needs a key now and text.pollinations.ai is the old endpoint -> FreeProviders.POLLINATIONS uses https://gen.pollinations.ai/v1/chat/completions, models openai/gpt-5.4-nano then openai, still tried anonymously (401 -> skipped 10 min). UI box text and contract test updated. (2) OpenRouter models: openrouter/free first. Groq model ids (llama-3.3-70b-versatile, llama-3.1-8b-instant) match current docs.
Verdict: Part 1 is COMPLETE AS WRITTEN CODE (all planned pieces exist and are wired) but only STATICALLY VERIFIED. Not compiled, 37 FreeProvidersTest tests never run, no live provider call, no phone test.
Reliable free route for the owner: a free Groq key (reused from the speech key) or an OpenRouter key. No key = offline model + offline skills only.
Next: PART 2 (personal memory), see NEXT_ACCOUNT_PROMPT_v20_PART2.md. Standing rule: every part ends with a zip + a new handover prompt.

## v18d (2026-10-10) - Part 2: personal memory (Kotlin NOT compiled here, Kotlin tests NOT run, phone NOT tested)
Voice (Hindi/Hinglish/English): "yaad rakh <fact>" / "remember that <fact>" / "<fact> yaad rakh", "mujhe kya yaad hai" / "what do you remember", "bhool ja <thing>" / "forget <thing>", "sab bhool ja" (spoken yes via askFirst). Kinds mem_save / mem_list / mem_forget / mem_forget_all are NOT in Brain.SAFE_KINDS (tests added).
NEW: PersonalMemory.kt (pure), PersonalMemoryStore.kt, PersonalMemoryTest.kt (generated), tools/memory_cases.py + gen_memory_test.py + test_memory_contract.py. CHANGED: Logic.kt (classify hook before Timers, LOUD_KINDS), NovaService.kt (handle short-circuit before brain.record + masking, 4 runCommand branches, memSave/memList/memForget/memForgetAll, chainFacts, local model gets facts), LocalBrains.chat(facts), ExtCfg.memoryInChain, MainActivity Bridge (getMemoryCount/getMemoryText/clearMemory/get+setMemoryInChain), ui.html memory box, SafetyInvariantsTest (+2).
Privacy: refuses OTP/password/PIN/CVV/card/Aadhaar-PAN-passport/bank account/any 6+ digit number (typed or spoken digits); max 100 facts x 200 chars, newest first, case-insensitive dedupe; stored only in SharedPreferences "nova_memory" (allowBackup=false); never logged; heard text of a memory command is NOT recorded by brain.record and is replaced by "(yaad rakhne ka command)" in chat/card; Gemini never gets facts; the online free chain gets at most 3 RELEVANT, non-contact-like facts and only while ExtCfg.memoryInChain is ON (default ON, UI switch); the on-device model gets up to 3 relevant facts.
Checked HERE: python3 tools/test_memory_contract.py ALL PASSED (94 checks: real Kotlin regexes + Python port of the logic over the shared table; found and fixed 2 real bugs); test_chain_contract.py + test_self_improve.py still pass; ui.html node --check OK (6 blocks); tokenizer bracket balance over every touched .kt; no `!!` / `catch (_` / TODO in touched files. NOT verified: Kotlin compile, the 14 PersonalMemoryTest + 2 safety tests, Android store, phone.
Phone test: say "nova yaad rakh mera naam Shiv hai" (reply "Theek hai, yaad rakh liya", chat shows "(yaad rakhne ka command)"); "nova mujhe kya yaad hai" (reads it back); "nova yaad rakh mera otp 4821" (refused, nothing stored); "nova bhool ja mera naam"; "nova sab bhool ja" then "haan"; Settings > YAAD box shows the count, DIKHAO shows the text, SAB HATAO needs two taps.
Next: PART 3 knowledge pack, see NEXT_ACCOUNT_PROMPT_v21_PART3.md.

## v22 (2026-10-10) - Part 3 SAVE-POINT (knowledge pack): matcher written, data 39/150+, NOT wired, nothing compiled or run
DONE (written, statically checked only: tokenizer bracket balance OK, no `!!`, no TODO, canon values never in STOP):
- NEW app/.../KnowledgeMatcher.kt (pure): STOP words, CANON (339 Hinglish spelling variants + synonyms), LIVE words (today/price/news... -> always null), integer dice score (THRESHOLD 60, TIE_MARGIN 5, MIN_OVERLAP 2, one typo forgiven only in words of 6+ letters), prepare/match/reply/parse(json via MiniJson). Not referenced by any other file yet, so app behaviour is unchanged.
- NEW tools/knowledge_src/k_science.py: 39 science/body entries (id, 5-6 question variants, Hinglish answer, English answer, tags). Checked: >=5 variants each, no LIVE word in any variant, answers short.
NOT DONE (see NEXT_ACCOUNT_PROMPT_v22_PART3.md): remaining ~115 entries (India, first-aid, math rules, daily how-tos, NOVA tips), tools/build_knowledge.py (merge to app/src/main/assets/knowledge.json), tools/validate_skillpack.py, tools/test_knowledge_contract.py (Python port + 100 question cases), KnowledgeStore.kt, KnowledgeMatcherTest.kt, wiring in NovaService.handle, docs.

## v23 SAVE-POINT: Part 3 knowledge pack, data + tools DONE, Kotlin wiring NOT done
Ladder level: written + statically checked + Python contract tests run in the sandbox. NOT compiled, NOT run on a phone, NOT in CI.
- DONE: assets/knowledge.json (193 entries, 1157 variants, built by tools/build_knowledge.py from tools/knowledge_src/k_*.py: science 39, india 39, health 30, math 28, daily 27, nova 30).
- DONE: tools/validate_skillpack.py (OK), tools/knowledge_port.py (Python port, reads STOP/CANON/LIVE/KEEP1 from KnowledgeMatcher.kt), tools/test_knowledge_contract.py (100+ cases, ALL PASSED).
- KnowledgeMatcher.kt changed in this chat: KEEP1 = setOf("c","d") (so "vitamin c" vs "vitamin d" differ) and STOP got "si","sa","sabse".
- NOT DONE: KnowledgeStore.kt, NovaService wiring, Kotlin tests (KnowledgeMatcherTest, knowledge.json test, SafetyInvariantsTest additions), self-test count line. The phone still behaves exactly as before: nothing calls the matcher.

## v24 (2026-10-10): Part 3 complete (knowledge pack wired), NOT compiled, NOT run on a phone
Ladder level: written + statically checked (brackets balanced in the new/edited files, no `!!`, no `catch (_`, no TODO) + Python contract tests pass in the sandbox. Kotlin NOT compiled, tests NOT run, CI NOT run, phone NOT tested.
- NEW KnowledgeStore.kt: lazy, cached, synchronized load of assets/knowledge.json (600 KB cap, never throws); answer(ctx, text, en) = KnowledgeMatcher.match + reply; count(ctx) for the self test.
- NovaService.handle: after Logic.classify / LocalSkills / shortcuts / groq text all gave nothing (c, c0, sk == null) and BEFORE brain.record(... "unknown"): junk is skipped; on a hit lastTurnLocal = true, lastKind = "knowledge", brain.record(now, text, "local", "knowledge"), the answer is returned. Runs before the offline translator and Gemini / free chain. Text only, never an action. In quiet-replies mode the answer is shown but not spoken (same as local_chat, "knowledge" is not in LOUD_KINDS).
- SelfTest: new line "Knowledge pack: N entries loaded" (WARN if 0).
- NEW test KnowledgeMatcherTest.kt (hits, language, no match, near miss, live words, too long, vitamin c vs d, tie, typo, tokens, parse good/bad, real pack: every entry's first variant finds itself). Expected values were cross-checked with tools/knowledge_port.py. SafetyInvariantsTest: "knowledge" and "local_skill" are not in Brain.SAFE_KINDS.
- Still true: python3 tools/build_knowledge.py, validate_skillpack.py, test_knowledge_contract.py all pass after any data change.
- NEXT: PART 4 (Hindi command model: Logic.norm keeps only a-z0-9, so Devanagari is junk; HindiRoman.kt exists) and PART 5 (integration + regression + one build.yml adding python3 tools/test_chain_contract.py, test_memory_contract.py, test_knowledge_contract.py, validate_skillpack.py). See NEXT_ACCOUNT_PROMPT_v24_PART4.md.

## v25 (2026-10-10): Part 4 complete (Hindi / Devanagari input), NOT compiled, NOT run on a phone
Ladder level: written + statically checked (brackets balanced, no `!!`, no `catch (_`, no TODO) + Python mirror tests pass in the sandbox. Kotlin NOT compiled, tests NOT run, CI NOT run, phone NOT tested.
- HindiRoman.kt extended: word table (command words, yes/no, numbers, double-a spellings, vitamin c/d, calls/messages) + NEW rule transliteration for every Devanagari word not in the table (consonants, matras, nukta, conjuncts via virama, anusvara, simple schwa deletion, Devanagari digits). hasDevanagari(), toRoman() unchanged in name. Only changes words, never approves / taps / sends.
- NovaService.handle(pcm, rawText): Devanagari is converted at the very top; the chat shows the original text; Logic.classify, LocalSkills, KnowledgeMatcher, free chain all see Roman. groqHear still converts too. A typed yes still never approves a risky action.
- Safety unchanged: SAFE_KINDS, risky labels, parseAnswer not touched. "हाँ" -> haan, "नहीं" -> nahi, "हाँ नहीं" -> false (tested).
- NEW tests: HindiRomanTest.kt (table words, rule words, vitamin c/d, digits/nukta/danda, odd input never throws, yes/no strict, classify equals the Roman command, junk before/after, Hindi questions find knowledge answers incl. the real pack, live word "आज" gives null). NEW tools/hindi_port.py + tools/test_hindi_contract.py (ALL PASSED).
- Known limits: spelling is a best guess (e.g. "खून" is in the table as khoon, but an unlisted word may come out as khun and miss a match); Hindi words of Sanskrit origin or long rare words may be spelled oddly; "ज़्यादा/तेज़" still map to "badhao" (old volume mapping). Hindi text only helps where Devanagari text arrives (typed keyboard, Groq Whisper); the offline Vosk model still returns Roman letters.
- NEXT: PART 5 (integration + regression + ONE build.yml for the owner to paste). See NEXT_ACCOUNT_PROMPT_v25_PART5.md.

## v26 (2026-10-10): Part 5 done (static review + CI file). Parts 1-4 all written; NOTHING compiled, NOTHING run on a phone
Ladder level: written + statically checked + Python contract tests run in the sandbox (5 scripts, all pass). Kotlin NOT compiled (this sandbox has no kotlinc / Gradle / Android SDK), CI NOT run, phone NOT tested.
- Static review of Part 3+4 files by hand: KnowledgeStore.kt (locking simplified so there is no non-local return inside synchronized), KnowledgeMatcher.kt (MiniJson.field/parse API checked), HindiRoman.kt (class named Syl, not Kotlin's Unit; explicit String type), NovaService.kt wiring (vals c, c0, sk, now, groqText all defined before use), SelfTest.kt (ctx and rec exist), the three new/changed test files (every expected value cross-checked with the Python ports; knowledge.json checked against the Kotlin parse rules: 193 unique ids matching the id regex, answers <= 324 chars, variants 3..90 chars). Source guards: no `!!`, no `catch (_`, no TODO in app/src/main.
- Build is Kotlin 1.9.24 / AGP 8.5.2 / JUnit 4.13.2; unit tests read "src/main/assets/knowledge.json" relative to the app/ module dir.
- NEW python-tests.yml (separate workflow, delivered as a download, NOT in the zip; the owner pastes it at https://github.com/devboutique0-wq/NOVA/new/main?filename=.github/workflows/python-tests.yml). It runs the source guards + validate_skillpack.py + test_knowledge_contract.py + test_hindi_contract.py + test_chain_contract.py + test_memory_contract.py. build.yml was NOT touched (its text was not available in the zip, so rewriting it blind could drop its model downloads / secret scan / keystore handling).
- NEXT: the owner uploads the zip, runs "Unpack zip", then "Build and Test APK". If red: ask only for the red lines of the failed step and fix them first. If green: install APK, ACTIVATE, run SELF TEST (look for "Knowledge pack: 193 entries loaded"), try a typed Hindi question, a knowledge question, and a voice command.

## v27 (2026-10-11) - build GREEN (CI #61 + Python tests #4), phone SELF TEST pass=25 fail=0 skip=1
- Offline llama.cpp engine REMOVED (library needs Kotlin 2.3 / AGP 8.9.1 / compileSdk 36): LlamaBrain.kt deleted, dependency removed, LocalBrains.installEngine is a no-op, offline-model button hidden. Stale OFFLINE BRAIN text still in ui.html (to fix).
- MainActivity.kt: PatternUnlock.isSet(this@MainActivity) (was `this` inside Bridge = compile error).
- ui.html: glow pack (look/animation only), CHAT + SETTINGS moved to the header, new SAARE FEATURES box in Settings (real status via existing bridge methods). Tested in a desktop browser with a fake bridge only: phone NOT tested.
- Gemini text on the owner's key: gemini-3.5-flash code=200 (phone self test). Image generation and Groq not tested on the phone yet.
- Full details: NEXT_ACCOUNT_PROMPT_v27_FINAL.md.

## v28 (2026-10-11): TASK AGENT ("ek baar bolo, NOVA khud kare"). Written + statically checked + Python contract test. Kotlin NOT compiled, phone NOT tested
Why: owner said "gallery kholo, 5th photo chuno, ChatGPT se edit karwao" and got "local mode me samajh nahi aaya". Cause: no handler for multi-step jobs (only single commands existed), and NOVA had no ChatGPT/Gemini-app control at all. "LOCAL MODE" badge only means no Gemini key saved (localMode = !hasKey).
- NEW AgentRules.kt (pure): isTask (prefix "kaam/agent/khud se", OR AI app + photo + edit words, OR gallery + "Nth photo/select"), parse (one JSON action), check (OK / CONFIRM / DENY), stuck, prompts. NEW AgentRulesTest.kt, NEW tools/test_agent_contract.py (passes).
- NovaAccessibilityService: agentSnapshot (numbered visible items, no password fields, text typed in boxes never listed), agentTap(index, long) with gesture fallback, agentType(index, text).
- NovaService: trigger in handle() (also for Groq-heard text), agentBegin (spoken yes first, tells the owner screen text goes to Gemini), agentRun loop (read screen -> Gemini one JSON action -> AgentRules.check -> run), caps 30 steps / 5 min, "stop/ruko" cancels, stuck detection, protected screens (settings, permission, payment/bank, NOVA itself) are refused AND never sent to the cloud.
- Safety: DENY pay/buy/subscribe/upgrade/transfer/order/password/otp; "send" auto only in ChatGPT + Gemini apps (owner approved with the first yes); delete/post/submit/send-elsewhere ask a spoken yes each time.
- Scroll sense: system prompt tells the model to scroll (down, then up) when the item is not visible; a scroll that changes nothing is reported to it as "end reached"; items beyond the 90 listed are announced as "N more items not listed".
- Limits (be honest with owner): works from the screen's accessibility TEXT only (no pixels), so a photo grid without labels is tapped by position; Xiaomi gallery may need long_tap; ChatGPT/Gemini screens change between app versions; each step is one Gemini call (needs the owner's Gemini key + internet).
- NOT done: no UI change (no screenshot), no phone test. Owner test order: 1) "kaam chatgpt kholo aur ek line likh do" (simple), 2) the photo job. On red CI: send only the red lines.
- v28b: the agent now also sends a small JPEG screenshot (<=640 px wide, quality 60, Android 11+, canTakeScreenshot in accessibility_config.xml) with each step, only on non-protected screens; if it fails it continues text-only. The owner may have to switch the NOVA Accessibility service OFF and ON once so Android grants the new capability. Every step is written to the chat as a "sys" line ("step N: tap [i] 'x' -> ok, screen changed [pic] [package]") so the owner can send it for fixing. Still NOT compiled / NOT phone tested.
- v28c LISTENING: command text used to come ONLY from offline Vosk (small, Roman-only guesses) unless a Groq key was saved. Now, after the wake word, if Vosk found no local command and (no Groq key or Groq failed), NovaService.geminiHear(pcm) transcribes the clip with the owner's Gemini key (prompt: word for word, Hindi/Hinglish in Roman letters) and the result goes through Logic.classify / AgentRules.isTask / knowledge / AI chain like Groq text. Clips under 0.8 s are never sent. yes/no answers still use ONLY local parsing. Cost: one extra Gemini call per non-local utterance (free-tier quota!). Best quality = Groq Whisper (owner has a Groq key saved, never tested): ask him to test it. Not compiled, not phone tested.
- v29: NEXT_ACCOUNT_PROMPT_v29_FINAL.md written (replaces v27 + v28 prompts; self-contained). Open question to owner: which free-image option (1 agent route, 2 voice Pollinations, 3 key slot).

## v30 (2026-10-11): FREE IMAGE BY VOICE ("nova ek billi ki photo banao"). Written + statically checked + Python contract test. Kotlin NOT compiled, CI NOT run, phone NOT tested
Why: owner asked for free AI image generation first. Before: images only via the chat-screen buttons and Gemini first (free providers only if the FREE FALLBACK switch was ON and Gemini failed).
- NEW ImageIntent.kt (pure): parse(text) -> null (not an image request) or Parsed(subject, blocked). Needs a make-verb (banao, bana do, make, create, draw...) AND a picture word (photo, tasveer, image, picture, painting, wallpaper...). Words that belong to other features (kholo, edit, chatgpt, gemini, gallery, select, camera, kheencho, send, share, whatsapp, call, kaam, agent...) make it return null, so the v28 task agent and camera commands keep working. Small Hindi->English noun/colour map (billi=cat ...); unknown words pass through. Block words (nude, nsfw, porn, sex...) -> refused.
- NovaService: imageBegin(). Trigger in handle() right after the agent trigger (typed chat and Groq/Gemini-heard text too). Replies at once ("... ki photo bana raha hu. Ye likha hua ek free online service ko jayega. 20 se 60 second lagenge"), then a worker thread runs FreeImage.run (Together with own key -> Pollinations without key -> Hugging Face with own token), saves with ImageGen.saveToGallery (Gallery > Pictures > NOVA), pushes the picture to the chat through NEW NovaService.imageListener (MainActivity connects it to the existing JS onImage) and speaks the result. One picture at a time. Prompt text is NOT written to brain.record.
- ImageGen.generate: when there is NO Gemini key (code -1) and no photo, free providers are tried directly (the Settings switch now only guards the "Gemini failed" fallback).
- NEW ImageIntentTest.kt, NEW tools/test_image_contract.py (reads the word sets from ImageIntent.kt; 19 cases pass). All 7 Python contract tests + validate_skillpack pass.
- UNKNOWN until the phone test: whether Pollinations' legacy endpoint (image.pollinations.ai) still answers without a key. Vendor articles (Aug 2026) say yes, limited to 1 request / 15 s and maybe a watermark; registering at auth.pollinations.ai is said to remove both. FreeImage retries once after 16 s on code 429. Check with Settings > FREE IMAGE TEST first. A Pollinations key slot is NOT built (not verified how the legacy endpoint takes a key).
- Limits: free FLUX models follow English prompts best; unmapped Hindi words go through as typed. Photo EDIT still needs Gemini. The agent route (chatgpt app makes the picture) is unchanged and untested.
- Owner test: 1) Settings > FREE IMAGE TEST (needs no key for Pollinations), 2) type in chat "ek billi ki photo banao" (typed works too), 3) say "nova ek lal gaadi ki photo banao", 4) "nova photo kholo" must still open the camera/gallery as before.

## v31 (2026-10-11): QUIET MODE + home page scroll. Written + statically checked + headless-browser layout test + 8 Python contract tests. Kotlin NOT compiled, CI NOT run, phone NOT tested
Owner wishes: everything falls back automatically, no provider/model names announced after a key is saved, no "permission" chatter, the home page must scroll.
- ROOT CAUSE of "home page does not scroll": ui.html did `app.className = on ? 'on' : ''` (3 places: ready(), the 'mode' event, setOn()), which wiped the `wrap` class of #app, so the flex column / height 100% / padding were lost after the first state change. Now `app.className = 'wrap ' + ...`. Added <style id="fix-scroll">: .wrap scrolls (overflow-y auto), children do not shrink, log min-height 140px. Headless Chromium (stub bridge): 360x520 and 360x640 scroll, 390x844 fits, no JS errors. tools/test_ui_contract.py guards this.
- Update Center popup ("KYA NAYA HAI", stale llama.cpp text) no longer opens by itself (ucAuto only stores the seen version, ucMaybe does not open). Offers wait in UPDATE CENTER; nothing is installed without the owner's yes (unchanged).
- Mode badge (#mode) hidden via CSS; the FREE FALLBACK checkbox is hidden (the fallback is automatic now).
- Automatic fallbacks: ImageGen.generate = Gemini, then (no photo) FreeImage providers without any switch; messages never name a provider (generic "Abhi photo nahi ban payi..."). ImageGen.generateDirect = Gemini only, used by Settings > IMAGE TEST so key problems stay visible there; FREE IMAGE TEST still shows per-provider results. Text chain (Groq/OpenRouter/Pollinations) and Gemini/Groq listening were already automatic.
- Removed chat/sys lines naming the provider: "Gemini ne suna: ...", "Groq: ...", "Groq se sunna nahi ho paya (...)" (silent fallback), agent texts "Gemini ka jawab...", spoken image text no longer says "free online service". Agent consent is now only "Kaam: X. Shuru karun? Haan ya nahi bolo." (the spoken yes stays). The statement that screen text + a small picture go to the AI service now lives once in Settings (key box help text); test_agent_contract checks it there.
- Permissions: Android never lets an app switch permissions on silently. What changed: the FIRST ACTIVATE asks microphone + notifications + contacts in one dialog; a contacts command with the permission missing and the app open shows the Android dialog at that moment (NovaService.permRequest) instead of sending the owner to a button. Accessibility, notification-access, overlay and brightness still need the owner's one-time switch in Android Settings (NOT automatable).
- UNCHANGED safety: spoken yes for call/send/pay/delete/buy and for agent start; protected screens never sent to the cloud; typed yes never approves; no silent installs; keys never shown.

## v17 UI-only patch (2026-10-11)
- See `UI_REFRESH_NOTES_v17.md` for scope and evidence.
- Changed only `ui.html` visual styling and `NovaHud.kt` floating-card controls; no NovaService / AI routing / voice-command logic was intentionally modified.
- New test: `tools/test_hud_controls.py`. All `tools/test_*.py` pass locally; all 9 inline JS blocks pass `node --check`; 75 web-to-Android bridge references have no missing method; NovaHud braces balance.
- Still required: GitHub Actions `Unpack zip` then `Build and Test APK`, followed by physical phone testing. Local Kotlin/Gradle build and browser visual inspection could not be completed in this environment.

## v32 (2026-10-11) - NOVA understands long / casual speech
Owner problem: "mere mobile lock kro turant" -> "samajh nahi aaya"; wants any short or long phrasing understood (Gemini key is saved).
Root causes found in code: (1) Logic.classify matched the WHOLE sentence ("lock" only), so filler words broke it; (2) with only a Gemini key, a capture the offline Vosk could not read counted as a "false wake" and was dropped BEFORE geminiHear; (3) the Gemini system prompt told the model to ask to repeat when unclear, the rough Vosk transcript misled it, and tool calls ran at default temperature.
Changes: Understand.kt (new, pure): filler words + ONE safe intent -> short phrase for Logic.classify (lock, home, back, recents, notifications, torch, volume, brightness, battery, time, date, media, camera, wifi/bluetooth page). Negation, questions, two intents, names/apps, unlock, tap/call/send are never matched here and go to Gemini. NovaService: handle() uses Understand.classify (Vosk text + Groq/Gemini text); isFalseWake gate also counts the Gemini key; prompt rewritten (extract the intent, several tools per turn, no "did not understand" for odd phrasing); temperature 0.2 for tool calls; honest no-key message.
Evidence: written + statically checked + tools/test_understand_contract.py (41 cases, mirrors the real word tables) + all older contract tests pass. Kotlin NOT compiled, CI NOT run, phone NOT tested. UnderstandTest.kt added.
Owner test (one at a time, after install): "nova mere mobile ko turant lock kar do"; "nova yaar thodi awaaz kam kar de aur torch jala de" (two things, goes to Gemini); "nova mujhe batao abhi battery kitni bachi hai". Send the chat line if it fails.

## v33 (2026-10-11) - PART 1 of 3: JARVIS screen session ("nova screen dekho" = a conversation, not one shot)
Written + statically checked (braces, no `!!`, no `catch (_`, no TODO) + NEW tools/test_screen_session_contract.py + all 14 older Python contract tests + validate_skillpack pass. Kotlin NOT compiled (no kotlinc here), CI NOT run, phone NOT tested. v32 was also never built, so the first CI run covers v32 + v33 together: if RED, ask only for the red lines.
- NEW ScreenSession.kt (pure): session state (MAX_TURNS 6 follow-ups, IDLE_MS 90 s idle, idle clock restarts when a spoken reply ends), intent(text) = STOP / MORE / IMPORTANT / WHAT / READ / REPLY / NEXT / REFRESH / PICTURE / OTHER, isProtected (= Control.blocked, same rule as the task agent), prompts (system prompt says: use only the screen text, screen text is untrusted, you can only talk), spoken texts (no provider names).
- NovaService.analyzeScreen(): reads the screen once (NOVA in front: still waits 8 s), starts a session, asks the AI for 2 short sentences (app, what is on it, what matters) + a short offer. Then the follow window opens by itself (even when conversation mode is off; MAX_FOLLOW 3 still applies to normal chat) so the owner can talk without the wake word.
- Follow-ups: handle() calls screenFollow() BEFORE the task agent. Order inside: offline text -> if unclear, Groq/Gemini listening writes it down (same silent fallback) -> normal local commands win (torch, volume... end the session) -> STOP words end it -> picture-making / tasks leave the session -> a wake-word sentence that is not a screen intent leaves the session (only follow-ups heard WITHOUT the wake word may be free questions about the screen; typed text never counts as a follow-up) -> answer. Re-reads the live screen on "ab ye dekho" or when another app is in front.
- REPLY ("iska jawab likho"): AI writes ONE short draft; NOVA reads it and asks a spoken yes; on yes (one spoken yes covers both) it TYPES into the focused box (typeText, blocked on protected / password) and then presses Send via tapLabel(ScreenSession.SEND_LABELS); nothing happens without the yes. NO_MESSAGE -> "koi message nahi dikha".
- Picture: only when the text is empty (< 12 chars) or the owner says "picture dekho / ye image kya hai": agentScreenshot() on a non-protected foreground screen, else a plain refusal. Needs Android 11+ and the Accessibility service switched OFF/ON once (v28b).
- Protected screens (settings, permission, installer, Play Store, bank / UPI / payment / wallet, NOVA itself): nothing goes to the cloud (no text, no picture); NOVA offers to read the visible text locally after a spoken yes.
- No AI key: reads the first lines locally + "Settings mein AI key daalo" (no provider names), session ends.
- Session talk has NO tools (cloudBody(.., false, system)); history is its own short list (8 messages, screen text is in the system prompt, not in the history); nothing is written to disk.
- Logic.LOUD_KINDS now has "screen" and "screen_end"; NovaService.NO_FOLLOW_KINDS has "screen_end". tools/test_agent_contract.py: the geminiHear guard now says 3 uses (definition, handle, screenFollow) and checks that the yes/no path (processAnswer) never listens through the cloud.
- NOT changed: ui.html (NO UI change), NovaAccessibilityService, alert monitor (Part 2), providers / Qwen (Part 3).
- Owner test (one at a time, phone): 1) open WhatsApp or Chrome, say "nova screen dekho" -> 2 short sentences; 2) without saying nova: "aur detail"; 3) "isme important kya hai"; 4) "ise padh ke sunao"; 5) "iska jawab likho" -> it reads a draft and asks yes/no (say yes only with a chat box open; on yes it types AND presses Send); 6) "ab ye dekho" after opening another app; 7) "ruko". Send the chat lines (and which step) if one fails.

## v34 (2026-10-11) - PART 2 of 3: screen ALERT fixed (rare, only real dialogs, asks instead of instructing)
Written + statically checked + NEW ScreenAlertTest.kt + NEW tools/test_screen_alert_contract.py + all 15 older Python contract tests + validate_skillpack pass. Kotlin NOT compiled, CI NOT run, phone NOT tested (v32 + v33 + v34 are still unbuilt: first CI run covers all three; if RED, ask only for the red lines).
Root cause of the repeating "Screen alert: failed": Logic.detectAlert matched generic words (failed, error, warning, blocked, could not...) in any short line of ANY app, guard was only 2 min per alert.
- NEW ScreenAlert.kt (pure): detect(pkg, lines, ownPkg) needs a DIALOG: <= 20 lines, a short (<= 100 chars) line with an alert phrase AND a whole-line button (OK / Retry / Try again / Cancel / Close / Close app / Wait / Dismiss / Got it ... + a few Hindi). Exception: system "isn't responding / has stopped / keeps stopping" dialogs from package "android" need no button. Dropped on their own: warning, blocked, failure. Ignored apps: messaging, browsers, social, news, mail, launcher, keyboards, NOVA itself, and every protected app (ScreenSession.isProtected = settings, installer, Play Store, bank/UPI/payment).
- Gate: same (app + alert) snoozed 10 min, at most 3 spoken alerts per hour, never two within 60 s. Recorded only when NOVA really asked. Screen off (PowerManager.isInteractive false) = silent.
- NovaService.screenAlertAsk (main thread): refuses while driving mode, a screen session is open, busy / listening / speaking / a yes is pending / follow or answer window. Speaks ONE line: "<App> mein <reason>. Detail bolun? Haan bolo." (reason in words, no provider names; English variant "Shall I tell you more? Say yes."). A spoken yes -> screenStartFrom (shared with analyzeScreen) = the Part 1 session on that screen, follow window stays open (alertKind). No yes = silence (pending expires after 30 s; a spoken no says "Theek hai, cancel kar diya"). A "sys" chat line "alert: pkg|phrase | line" shows why it fired (debug, not spoken).
- Removed: Logic.detectAlert, Logic.shouldAnnounce, ALERT_* constants and their LogicTest cases (replaced by ScreenAlertTest).
- Unchanged: the on/off switch (Settings screen monitor), no UI change.
- Unverified on phone: whether the answer window opens right after the alert question when NOVA was asleep (same mechanism as other spoken confirmations).
- Owner test (one at a time): 1) Screen monitor ON; open WhatsApp/Chrome page containing "payment failed" -> NOVA must stay silent for 10 minutes; 2) trigger a real dialog (e.g. a hung app "isn't responding" or an app showing "Something went wrong" + OK) -> ONE spoken question; say "haan" -> screen session starts; 3) leave it alone -> silence. Send the chat lines if it fails.

## v35 (2026-10-11) - PART 3 of 3: Qwen fallback + silent AUTO SETUP. Written + statically checked + NEW AutoSetupPlanTest.kt + NEW tools/test_autosetup_contract.py + all older Python contract tests pass. Kotlin NOT compiled, CI NOT run, phone NOT tested (v32..v35 all unbuilt: first CI run covers all four; if RED ask only for the red lines)
Decisions taken without asking (owner said "Part 3 complete karo"): online Qwen only (option A). Offline Qwen (option B, 491 MB + llama.cpp engine that needs Kotlin 2.3 / AGP 8.9.1) was NOT built: not started, so the working build is untouched. Say so honestly if he asks.
- Qwen id looked up 2026-10-11 (web): Groq lists qwen/qwen3.8-27b (preview, same endpoint + same key as the Groq key the owner already has = nothing new to set up). OpenRouter had qwen/qwen3.8-27b:free but it was REMOVED from the free list on 2026-10-06, so there is no OpenRouter Qwen row. Sources: github.com/cyclez2000/openrouter-free-models issue #81, console.groq.com/docs/models.
- FreeProviders: new GROQ_QWEN (id "groqqwen", own cooldown so Groq-llama quota and Qwen quota are tracked separately, keyName "groq"), ONE id table FreeProviders.QWEN_MODELS_GROQ. Order: Gemini -> Groq -> Qwen (Groq) -> OpenRouter -> Pollinations -> offline skills. Text only, never an action. No provider name in any spoken / chat reply (failText unchanged, tested). Preview models can vanish: a 404/400 just moves on to the next provider.
- Unknown until the phone: Qwen3.x may spend its 350 max tokens on hidden reasoning (then content is empty = counted as a failed answer, chain moves on; <think> blocks are already stripped). If Qwen never answers, raise maxTokens for that provider only.
- NEW AutoSetupPlan.kt (pure state machine: VOICE + PROVIDERS tasks, back-off 1 min / 5 min / 30 min / 2 h / 6 h, 5 attempts, provider check repeats every 6 h, results vs retries) and NEW AutoSetup.kt (the ONE background runner, started by NovaService where ModelAuto.autoStart used to be called; stopped in onDestroy). Tasks: voice-check model download (ModelAuto.silentVoice, no chat text), tiny health request to every keyed provider (Groq, Qwen, OpenRouter). No pop-up, no speech, no chat line. Results = lines in Settings > SELF TEST (SelfTest now runs the provider check live and prints AutoSetup.log()).
- Permissions: UNCHANGED (just-in-time, v31). The Settings permission checklist with deep links (Accessibility, Notification access, Battery, overlay...) already existed in ui.html, so no UI change and no new promise. Android does NOT allow any app to switch on Accessibility / Notification access / Overlay / Brightness by itself: those stay one-time manual switches.
- Old tests updated for the new wiring: test_chain_contract (4 URLs / new order), test_voice_contract (auto download now starts via AutoSetup), FreeProvidersTest (order + Qwen failover tests).
- Owner test (one at a time): 1) Settings > SAB TEST KARO: lines "Free AI Groq ..." and "Free AI Qwen (via Groq) (qwen/qwen3.8-27b)" must be PASS (WARN "model abhi nahi mila" means Groq removed the preview id: tell me, one line to change); 2) turn Gemini key off / use a question when Gemini is rate limited -> an answer still comes (Groq, then Qwen); 3) fresh install: after ACTIVATE + allow, the voice model downloads by itself (SELF TEST shows "Auto setup PASS Awaaz model").
- Still open (owner's call): offline Qwen needs its own build experiment; OpenRouter Qwen row if a free Qwen returns; battery-optimisation prompt stays a button in the checklist.

## v36 (2026-10-11) - free CHINESE AI added to the fallback (owner request). Written + statically checked + tests; Kotlin NOT compiled, CI NOT run, phone NOT tested
Research (web, 2026-10-11): usable = Zhipu / Z.ai GLM Flash models (glm-4.7-flash, glm-4.5-flash priced at zero on docs.z.ai, e-mail sign-up, no card per freellm.net; endpoint https://api.z.ai/api/paas/v4/chat/completions from docs.z.ai). NOT usable: DeepSeek and Moonshot (no free API), SiliconFlow (needs Chinese phone, e-mail "may work"), ModelScope Qwen (Alibaba account / phone), Baidu (only via OpenRouter, `baidu/cobuddy:free`, needs OpenRouter key which the chain already supports: OpenRouter `openrouter/free` auto-picks free models). Groq also lists minimax/minimax-m2.7 (Chinese) as preview, limits not public: not added.
- FreeProviders: new ZAI provider (id "zai", key slot "zai", ids in ONE table ZAI_MODELS), new FreeProvider.extra + buildBody(extra=) = `"thinking":{"type":"disabled"}` for GLM so the 350 tokens are not eaten by hidden reasoning (UNVERIFIED: if Z.ai rejects the field it returns 400 and the chain moves on; then remove `extra`). Order: Gemini -> Groq -> Qwen (Groq) -> GLM (Z.ai) -> OpenRouter -> Pollinations. Needs the owner's own free Z.ai key (z.ai, e-mail only).
- Settings > FREE ONLINE AI: new key box "Z.ai (GLM...) key" + Z.AI SAVE / HATAO + checklist row; the text says the question goes to a server in China. Bridge: saveZaiKey / hasZaiKey / clearZaiKey (key never sent back). AutoSetup health check + SELF TEST cover it automatically when a key exists.
- Tests: FreeProvidersTest (order, body JSON with the extra member, Groq+Qwen quota -> GLM answers), test_chain_contract, test_autosetup_contract updated.
- Owner steps: 1) z.ai par e-mail se sign-up -> API key banao; 2) Settings > Z.AI key paste -> Z.AI SAVE; 3) SAB TEST KARO: line "Free AI GLM (Z.ai, China) (glm-4.7-flash)" PASS ya WARN. WARN "model nahi mila" = id changed, one-line fix in ZAI_MODELS.
