package com.nova.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import java.io.ByteArrayOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * What this service does (and nothing else):
 *  1. Global navigation (home/back/recents/notifications/quick settings/lock) on a local voice command.
 *  2. Press the green SEND button in WhatsApp after the user said "yes" (WhatsApp packages only,
 *     only when the text box holds exactly the confirmed message, 15 s time limit).
 *  3. Read the visible accessibility TEXT when the user says "analyze screen", or - only if the user
 *     switched Screen Monitoring ON - scan it locally (debounced) for obvious error/warning wording.
 *  4. TASK AGENT (v28): only after the owner said "yes" to a spoken task, it lists the visible items (no
 *     password fields, no text typed into boxes) and taps / types by index. NovaService decides what is allowed
 *     (AgentRules + Control). On protected screens (settings, payment, bank) the list is empty.
 * It never stores screen text. Screen text leaves the phone ONLY during a confirmed agent task (to the owner's Gemini key).
 */
class NovaAccessibilityService : AccessibilityService() {

    class Snap(val pkg: String, val lines: List<String>)

    companion object {
        @Volatile var instance: NovaAccessibilityService? = null
        private val PKGS = setOf("com.whatsapp", "com.whatsapp.w4b")
        private val SEND_WORDS = setOf("send", "भेजें", "भेजे", "enviar", "senden", "envoyer")
        private const val TIMEOUT_MS = 15000L
        private const val DEBOUNCE_MS = 1000L
        private const val MIN_SCAN_GAP_MS = 3000L
        private const val MAX_LINES = 300

        fun armSend(message: String, cb: (Boolean) -> Unit) {
            val s = instance
            if (s == null) cb(false) else s.arm(message, cb)
        }

        /**
         * Visible text of the active window. Password fields are never read. Editable fields (what the
         * user is typing) are only included when [includeEditable] is true (local use only).
         * Returns null when Accessibility is not connected or Android exposes no window.
         */
        fun readScreen(includeEditable: Boolean): Snap? {
            val s = instance ?: return null
            var root = s.rootInActiveWindow
            if (root == null || root.packageName?.toString() == s.packageName) {
                val alt = otherAppRoot(s)
                if (alt != null) root = alt
            }
            if (root == null) return null
            val out = ArrayList<String>()
            collect(root, 0, out, includeEditable)
            return Snap(root.packageName?.toString() ?: "", out)
        }

        /** Top application window that is NOT NOVA (used when NOVA's own card or chat has the focus). */
        private fun otherAppRoot(s: NovaAccessibilityService): AccessibilityNodeInfo? {
            return try {
                s.windows
                    .filter { it.type == android.view.accessibility.AccessibilityWindowInfo.TYPE_APPLICATION }
                    .sortedByDescending { it.layer }
                    .mapNotNull { it.root }
                    .firstOrNull { it.packageName?.toString() != s.packageName }
            } catch (e: Exception) { null }
        }

        fun foregroundPackage(): String? = instance?.rootInActiveWindow?.packageName?.toString()

        fun performGlobalAction(action: Int): Boolean = instance?.performGlobalAction(action) ?: false

        // ------------------------------------------------------------------ voice screen control
        // Rules (what is allowed) live in Control.kt. These must run on a worker thread (they may wait).

        /** code: ok, no_acc, no_window, blocked, not_found, ambiguous:N, no_focus, password, failed. */
        class Ctl(val ok: Boolean, val code: String)

        /** A cheap fingerprint of the visible text, to tell whether an action changed the screen. */
        fun screenSignature(): Int = readScreen(false)?.lines?.hashCode() ?: 0

        fun tapLabel(label: String): Ctl {
            val s = instance ?: return Ctl(false, "no_acc")
            val root = s.rootInActiveWindow ?: return Ctl(false, "no_window")
            if (Control.blocked(root.packageName?.toString(), s.packageName, "tap")) return Ctl(false, "blocked")
            val exact = ArrayList<AccessibilityNodeInfo>()
            val part = ArrayList<AccessibilityNodeInfo>()
            findLabel(root, 0, label, exact, part)
            val list = if (exact.isNotEmpty()) exact else part
            if (list.isEmpty()) return Ctl(false, "not_found")
            if (list.size > 1) return Ctl(false, "ambiguous:" + list.size)
            return if (s.clickNode(list[0])) Ctl(true, "ok") else Ctl(false, "failed")
        }

        fun typeText(text: String): Ctl {
            val s = instance ?: return Ctl(false, "no_acc")
            val root = s.rootInActiveWindow ?: return Ctl(false, "no_window")
            if (Control.blocked(root.packageName?.toString(), s.packageName, "type")) return Ctl(false, "blocked")
            val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return Ctl(false, "no_focus")
            if (node.isPassword) return Ctl(false, "password")
            if (!node.isEditable) return Ctl(false, "no_focus")
            val old = node.text?.toString() ?: ""
            val hint = node.hintText?.toString()
            val base = if (hint != null && old == hint) "" else old      // an empty box shows its hint as text
            val args = Bundle()
            args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, base + text)
            return if (node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) Ctl(true, "ok") else Ctl(false, "failed")
        }

        fun scrollDir(dir: String): Ctl {
            val s = instance ?: return Ctl(false, "no_acc")
            val path = Control.swipePath(dir) ?: return Ctl(false, "failed")
            val dm = s.resources.displayMetrics
            val p = Path()
            p.moveTo(path[0] * dm.widthPixels, path[1] * dm.heightPixels)
            p.lineTo(path[2] * dm.widthPixels, path[3] * dm.heightPixels)
            val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 320)).build()
            val latch = CountDownLatch(1)
            var done = false
            val accepted = s.dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) { done = true; latch.countDown() }
                override fun onCancelled(gestureDescription: GestureDescription?) { latch.countDown() }
            }, null)
            if (!accepted) return Ctl(false, "failed")
            try { latch.await(1500, TimeUnit.MILLISECONDS) } catch (e: InterruptedException) { }
            return if (done) Ctl(true, "ok") else Ctl(false, "failed")
        }


        // ------------------------------------------------------------------ task agent (v28)
        // Items of the last agentSnapshot(), so a later tap-by-index hits the same node. Worker thread only.
        private val agentRefs = ArrayList<AccessibilityNodeInfo>()

        /** Package + numbered visible items of the top app window. null = Accessibility off or no readable window. */
        fun agentSnapshot(): Pair<String, List<AgentRules.Node>>? {
            val s = instance ?: return null
            var root = s.rootInActiveWindow
            if (root == null || root.packageName?.toString() == s.packageName) {
                val alt = otherAppRoot(s)
                if (alt != null) root = alt
            }
            if (root == null) return null
            val refs = ArrayList<AccessibilityNodeInfo>()
            val out = ArrayList<AgentRules.Node>()
            collectAgent(root, 0, refs, out)
            synchronized(agentRefs) {
                agentRefs.clear()
                agentRefs.addAll(refs)
            }
            return Pair(root.packageName?.toString() ?: "", out)
        }

        private fun collectAgent(n: AccessibilityNodeInfo?, depth: Int, refs: ArrayList<AccessibilityNodeInfo>, out: ArrayList<AgentRules.Node>) {
            if (n == null || depth > 30 || out.size >= 120) return
            try {
                if (!n.isVisibleToUser) return
                if (n.isPassword) return
                val t0 = n.text?.toString()?.trim() ?: ""
                val d0 = n.contentDescription?.toString()?.trim() ?: ""
                val edit = n.isEditable
                // what the owner typed in a box is never listed: only its hint and whether it is empty or filled
                val text = if (edit) {
                    val hint = n.hintText?.toString()?.trim() ?: ""
                    val filled = t0.isNotEmpty() && t0 != hint
                    (if (filled) "[text box, filled]" else "[text box, empty]") + (if (hint.isNotEmpty()) " " + hint.take(40) else "")
                } else t0
                val keep = text.isNotEmpty() || d0.isNotEmpty() || n.isClickable || edit || n.isChecked || n.isSelected
                if (keep) {
                    val r = Rect()
                    n.getBoundsInScreen(r)
                    if (r.width() > 0 && r.height() > 0) {
                        val cls = n.className?.toString()?.substringAfterLast('.') ?: ""
                        out.add(AgentRules.Node(out.size, text.take(80), d0.take(80), cls.take(20), n.isClickable, edit, n.isChecked || n.isSelected))
                        refs.add(n)
                    }
                }
                for (i in 0 until n.childCount) collectAgent(n.getChild(i), depth + 1, refs, out)
            } catch (e: Exception) {
                // node went away while walking: ignore
            }
        }

        private fun agentNode(index: Int): AccessibilityNodeInfo? {
            val n = synchronized(agentRefs) { agentRefs.getOrNull(index) } ?: return null
            return try { if (n.refresh()) n else null } catch (e: Exception) { null }
        }

        /** Tap (or long press) item [index] of the last snapshot. Clicks the node; if Android refuses, taps its centre. */
        fun agentTap(index: Int, long: Boolean): Ctl {
            val s = instance ?: return Ctl(false, "no_acc")
            val n = agentNode(index) ?: return Ctl(false, "not_found")
            if (n.isPassword) return Ctl(false, "password")
            if (!long && s.clickNode(n)) return Ctl(true, "ok")
            val r = Rect()
            n.getBoundsInScreen(r)
            if (r.width() <= 0 || r.height() <= 0) return Ctl(false, "failed")
            return gestureTap(s, r.exactCenterX(), r.exactCenterY(), if (long) 650L else 70L)
        }

        /** Types into item [index] (its content is replaced), or appends to the focused box when index < 0. */
        fun agentType(index: Int, text: String): Ctl {
            if (index < 0) return typeText(text)
            val n = agentNode(index) ?: return Ctl(false, "not_found")
            if (n.isPassword) return Ctl(false, "password")
            if (!n.isEditable) return Ctl(false, "no_focus")
            n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            val args = Bundle()
            args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            return if (n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) Ctl(true, "ok") else Ctl(false, "failed")
        }


        /**
         * v28: a small JPEG of the screen (Android 11+, needs canTakeScreenshot). null when not possible
         * (old Android, secure window, service not re-enabled yet): the agent then continues with text only.
         */
        @android.annotation.TargetApi(30)
        fun agentScreenshot(): ByteArray? {
            val s = instance ?: return null
            if (Build.VERSION.SDK_INT < 30) return null
            val latch = CountDownLatch(1)
            val holder = arrayOfNulls<ByteArray>(1)
            try {
                s.takeScreenshot(android.view.Display.DEFAULT_DISPLAY, s.mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                        try {
                            val hb = r.hardwareBuffer
                            val hw = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
                            val soft = hw?.copy(Bitmap.Config.ARGB_8888, false)
                            hb.close()
                            if (soft != null) {
                                val w = minOf(soft.width, 640)
                                val h = maxOf(1, soft.height * w / soft.width)
                                val small = Bitmap.createScaledBitmap(soft, w, h, true)
                                val bos = ByteArrayOutputStream()
                                small.compress(Bitmap.CompressFormat.JPEG, 60, bos)
                                holder[0] = bos.toByteArray()
                            }
                        } catch (e: Exception) {
                            holder[0] = null
                        }
                        latch.countDown()
                    }

                    override fun onFailure(errorCode: Int) { latch.countDown() }
                })
                latch.await(3000, TimeUnit.MILLISECONDS)
            } catch (e: Exception) {
                return null
            }
            return holder[0]
        }

        private fun gestureTap(s: NovaAccessibilityService, x: Float, y: Float, ms: Long): Ctl {
            val p = Path()
            p.moveTo(x, y)
            val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, ms)).build()
            val latch = CountDownLatch(1)
            var done = false
            val accepted = s.dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) { done = true; latch.countDown() }
                override fun onCancelled(gestureDescription: GestureDescription?) { latch.countDown() }
            }, null)
            if (!accepted) return Ctl(false, "failed")
            try { latch.await(2000, TimeUnit.MILLISECONDS) } catch (e: InterruptedException) { }
            return if (done) Ctl(true, "ok") else Ctl(false, "failed")
        }

        private fun findLabel(
            n: AccessibilityNodeInfo?, depth: Int, label: String,
            exact: ArrayList<AccessibilityNodeInfo>, part: ArrayList<AccessibilityNodeInfo>
        ) {
            if (n == null || depth > 30 || exact.size + part.size > 20) return
            try {
                if (!n.isVisibleToUser) return
                if (!n.isPassword) {
                    var best = 0
                    val t = n.text?.toString()
                    val d = n.contentDescription?.toString()
                    if (!t.isNullOrBlank()) best = maxOf(best, Control.matchScore(t, label))
                    if (!d.isNullOrBlank()) best = maxOf(best, Control.matchScore(d, label))
                    if (best == 2) exact.add(n) else if (best == 1) part.add(n)
                }
                for (i in 0 until n.childCount) findLabel(n.getChild(i), depth + 1, label, exact, part)
            } catch (e: Exception) {
                // node went away while walking: ignore
            }
        }

        /** Cancels pending scans at once when monitoring is switched off. */
        fun monitorChanged() { instance?.onMonitorChanged() }

        fun isEnabled(ctx: Context): Boolean {
            if (instance != null) return true
            val s = Settings.Secure.getString(
                ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            return s.split(':').any {
                val c = ComponentName.unflattenFromString(it)
                c != null && c.packageName == ctx.packageName && c.className.endsWith("NovaAccessibilityService")
            }
        }

        private fun collect(n: AccessibilityNodeInfo?, depth: Int, out: ArrayList<String>, includeEditable: Boolean) {
            if (n == null || depth > 30 || out.size >= MAX_LINES) return
            try {
                if (!n.isVisibleToUser) return
                if (!n.isPassword && (includeEditable || !n.isEditable)) {
                    val t = n.text?.toString()?.trim()
                    val d = n.contentDescription?.toString()?.trim()
                    val s = if (!t.isNullOrBlank()) t else d
                    if (!s.isNullOrBlank()) out.add(s.take(200))
                }
                for (i in 0 until n.childCount) collect(n.getChild(i), depth + 1, out, includeEditable)
            } catch (e: Exception) {
                // node went away while walking: ignore
            }
        }
    }

    private class Job(val message: String, val cb: (Boolean) -> Unit, val deadline: Long)

    private val h = Handler(Looper.getMainLooper())
    private val cfg by lazy { Cfg(this) }
    private var job: Job? = null
    private var scanQueued = false
    private var lastScanAt = -MIN_SCAN_GAP_MS
    private var lastAlertAt = -1L
    private var lastAlertKey = ""

    private val tick = object : Runnable {
        override fun run() {
            val j = job ?: return
            if (SystemClock.elapsedRealtime() > j.deadline) { done(false); return }
            if (!attempt()) h.postDelayed(this, 500)
        }
    }

    private val scan = Runnable {
        scanQueued = false
        if (!cfg.screenMonitor) return@Runnable
        lastScanAt = SystemClock.elapsedRealtime()
        val snap = readScreen(false) ?: return@Runnable
        if (snap.pkg == packageName || snap.pkg in PKGS && job != null) return@Runnable
        val hit = Logic.detectAlert(snap.lines) ?: return@Runnable
        val key = snap.pkg + "|" + hit
        val now = SystemClock.elapsedRealtime()
        if (!Logic.shouldAnnounce(now, lastAlertAt, lastAlertKey, key)) return@Runnable
        // NovaService only speaks if it is idle (not busy, not waiting for a confirmation, not talking).
        if (NovaService.instance?.announceIfIdle(
                "Screen alert: $hit. Say analyze screen for details."
            ) == true
        ) {
            lastAlertAt = now
            lastAlertKey = key
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        updateMask()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        h.removeCallbacksAndMessages(null)
        scanQueued = false
        val j = job
        job = null
        j?.cb?.invoke(false)
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (job != null) attempt()
        if (!cfg.screenMonitor) return
        if (e?.packageName?.toString() == packageName) return
        if (scanQueued) return
        scanQueued = true
        val wait = maxOf(DEBOUNCE_MS, lastScanAt + MIN_SCAN_GAP_MS - SystemClock.elapsedRealtime())
        h.postDelayed(scan, wait)
    }

    private fun onMonitorChanged() {
        h.post {
            if (!cfg.screenMonitor) {
                h.removeCallbacks(scan)
                scanQueued = false
            }
            updateMask()
        }
    }

    /** Content-change events are only requested while they are actually needed. */
    private fun updateMask() {
        try {
            val info = serviceInfo ?: return
            val wantContent = cfg.screenMonitor || job != null
            info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                (if (wantContent) AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED else 0)
            serviceInfo = info
        } catch (e: Exception) {
            // service is shutting down
        }
    }

    private fun arm(message: String, cb: (Boolean) -> Unit) {
        h.post {
            val old = job
            job = Job(message, cb, SystemClock.elapsedRealtime() + TIMEOUT_MS)
            old?.cb?.invoke(false) // a newer message replaces (and cancels) the older one
            updateMask()
            h.removeCallbacks(tick)
            h.postDelayed(tick, 700)
        }
    }

    private fun done(ok: Boolean) {
        val j = job
        job = null
        h.removeCallbacks(tick)
        updateMask()
        j?.cb?.invoke(ok)
    }

    /** True when the job is finished (sent). False = keep waiting. */
    private fun attempt(): Boolean {
        val j = job ?: return true
        val root = rootInActiveWindow ?: return false
        val pkg = root.packageName?.toString() ?: return false
        if (pkg !in PKGS) return false
        // Only press send when the text box holds exactly the message the user confirmed.
        val entry = root.findAccessibilityNodeInfosByViewId("$pkg:id/entry")?.firstOrNull()
            ?: findEditable(root, 0) ?: return false
        val typed = entry.text?.toString() ?: return false
        if (!Logic.sameMessage(typed, j.message)) return false
        val send = findSend(root, pkg) ?: return false
        if (clickNode(send)) { done(true); return true }
        return false
    }

    private fun findEditable(n: AccessibilityNodeInfo?, depth: Int): AccessibilityNodeInfo? {
        if (n == null || depth > 14) return null
        if (n.isEditable && n.className?.toString()?.endsWith("EditText") == true) return n
        for (i in 0 until n.childCount) {
            val r = findEditable(n.getChild(i), depth + 1)
            if (r != null) return r
        }
        return null
    }

    private fun findSend(root: AccessibilityNodeInfo, pkg: String): AccessibilityNodeInfo? {
        root.findAccessibilityNodeInfosByViewId("$pkg:id/send")?.firstOrNull()?.let { return it }
        return search(root, 0)
    }

    private fun search(n: AccessibilityNodeInfo?, depth: Int): AccessibilityNodeInfo? {
        if (n == null || depth > 12) return null
        val d = n.contentDescription?.toString()?.trim()?.lowercase()
        if (d != null && d in SEND_WORDS && n.isClickable) return n
        for (i in 0 until n.childCount) {
            val r = search(n.getChild(i), depth + 1)
            if (r != null) return r
        }
        return null
    }

    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = n
        var depth = 0
        while (cur != null && depth < 4) {
            if (cur.isClickable && cur.isEnabled) return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            cur = cur.parent
            depth++
        }
        return false
    }
}
