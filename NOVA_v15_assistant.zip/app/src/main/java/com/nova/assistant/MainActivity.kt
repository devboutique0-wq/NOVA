package com.nova.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var cfg: Cfg
    private var testTts: TextToSpeech? = null
    private var listenerOwned = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        cfg = Cfg(this)
        LocalBrains.installEngine(this)
        SecureStore.migrateOld(this)
        SecureStore.migrateSingleToPool(this)
        web = WebView(this)
        hardenWebView(web)
        web.setBackgroundColor(0)
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl(ASSET_URL)
        setContentView(web)
        boostRefresh()
        NovaService.listener = { role, text ->
            runOnUiThread {
                if (!isDestroyed) {
                    web.evaluateJavascript(
                        "onNova(" + JSONObject.quote(role) + "," + JSONObject.quote(text) + ")", null
                    )
                }
            }
        }
        NovaService.learnListener = { runJs("onLearn()") }
        NovaService.publishListener = { ok, msg, url ->
            runJs("onPublish(" + ok + "," + JSONObject.quote(msg) + "," + JSONObject.quote(url) + ")")
        }
        NovaService.siteListener = { ok, msg, html, saved ->
            runJs("onSite(" + ok + "," + JSONObject.quote(msg) + "," + JSONObject.quote(html) + "," + JSONObject.quote(saved) + ")")
        }
        NovaService.imageListener = { ok, msg, thumb, saved ->
            runJs("onImage(" + ok + "," + JSONObject.quote(msg) + "," + JSONObject.quote(thumb) + "," + JSONObject.quote(saved) + ")")
        }
        NovaService.permRequest = { what ->
            if (what == "contacts") runOnUiThread { if (!isDestroyed) requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), REQ_CONTACTS) }
        }
        listenerOwned = true
        handleIntent(intent)
    }

    /** The page is a local asset only: no file/content access, no navigation away, no network sub-requests. */
    private fun hardenWebView(w: WebView) {
        val s = w.settings
        s.javaScriptEnabled = true
        s.mediaPlaybackRequiresUserGesture = false   // lets the opening sound play without a tap
        s.domStorageEnabled = true                  // remembers the sound on/off choice
        s.allowFileAccess = false              // file:///android_asset/ is always readable regardless
        s.allowContentAccess = false
        s.allowFileAccessFromFileURLs = false
        s.allowUniversalAccessFromFileURLs = false
        s.setGeolocationEnabled(false)
        s.javaScriptCanOpenWindowsAutomatically = false
        s.setSupportMultipleWindows(false)
        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                // Never navigate anywhere except our own page.
                return request?.url?.toString() != ASSET_URL
            }

            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val u = request?.url?.toString() ?: return blocked()
                return if (u.startsWith(ASSET_PREFIX) || u.startsWith("data:") || u.startsWith("blob:")) null else blocked()
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                if (url != null && !url.startsWith(ASSET_PREFIX)) view?.stopLoading()
            }
        }
    }

    /** Smoothness: use the phone's highest refresh rate (90/120 Hz) while NOVA is on screen. */
    @Suppress("DEPRECATION")
    private fun boostRefresh() {
        try {
            val modes = windowManager.defaultDisplay.supportedModes
            var best: android.view.Display.Mode? = null
            for (m in modes) { if (best == null || m.refreshRate > best.refreshRate) best = m }
            if (best != null) {
                val lp = window.attributes
                lp.preferredDisplayModeId = best.modeId
                window.attributes = lp
            }
        } catch (e: Throwable) {
        }
    }

    private fun blocked() = WebResourceResponse("text/plain", "utf-8", 403, "Blocked", emptyMap(), ByteArrayInputStream(ByteArray(0)))

    /** Back: the page decides (close sheet / settings, play the closing animation, or leave). */
    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.novaBack?novaBack():'exit')") { r ->
            if (r == null || r.contains("exit")) moveTaskToBack(true)
        }
    }

    @Suppress("DEPRECATION")
    private fun vibe(ms: Long) {
        try {
            val v: android.os.Vibrator? = if (Build.VERSION.SDK_INT >= 31) {
                getSystemService(android.os.VibratorManager::class.java)?.defaultVibrator
            } else {
                getSystemService(VIBRATOR_SERVICE) as? android.os.Vibrator
            }
            if (v == null) return
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(android.os.VibrationEffect.createOneShot(ms, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                v.vibrate(ms)
            }
        } catch (e: Throwable) {
        }
    }

    override fun onResume() {
        super.onResume()
        NovaService.uiVisible = true
        pushFlow("resumed")
        HealthCheck.auto(this, web)      // back from an Android settings screen: the page re-checks its permission list
    }

    override fun onPause() {
        NovaService.uiVisible = false
        super.onPause()
    }

    override fun onNewIntent(i: Intent?) {
        super.onNewIntent(i)
        setIntent(i)
        handleIntent(i)
    }

    override fun onDestroy() {
        NovaService.uiVisible = false
        if (listenerOwned) {
            NovaService.listener = null
            NovaService.learnListener = null
            NovaService.publishListener = null
            NovaService.siteListener = null
            NovaService.imageListener = null
            NovaService.permRequest = null
        }
        testTts?.shutdown()
        testTts = null
        (web.parent as? ViewGroup)?.removeView(web)
        web.removeJavascriptInterface("Android")
        web.destroy()
        super.onDestroy()
    }

    // Tapped the "NOVA is off" notification after a phone restart (a visible, user-initiated start).
    private fun handleIntent(i: Intent?) {
        if (i?.getBooleanExtra("autostart", false) == true) {
            i.removeExtra("autostart")
            if (!NovaService.running && startFlow(false) == "started") moveTaskToBack(true)
        }
    }

    private fun isDefaultAssistant(): Boolean = try {
        (Settings.Secure.getString(contentResolver, "assistant") ?: "").startsWith("$packageName/")
    } catch (e: Exception) { false }

    private fun granted(p: String) =
        checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    /**
     * Requests missing permissions (only reached from a user tap or a user-tapped notification),
     * then starts NOVA. Returns a short status word for the UI: started / perm / nomic.
     * afterResult=true means Android just answered a permission dialog, so we never ask again (no loop).
     */
    private fun startFlow(afterResult: Boolean): String {
        if (!granted(Manifest.permission.RECORD_AUDIO)) {
            if (afterResult) return "nomic"
            val ask = mutableListOf(Manifest.permission.RECORD_AUDIO)
            if (!granted(Manifest.permission.READ_CONTACTS)) ask.add(Manifest.permission.READ_CONTACTS)   // v31: one dialog the first time, never again
            if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) {
                ask.add(Manifest.permission.POST_NOTIFICATIONS)
            }
            runOnUiThread { requestPermissions(ask.toTypedArray(), REQ_START) }
            return "perm"
        }
        if (!afterResult && Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) {
            // Notification permission is needed so the foreground-service notification is visible.
            runOnUiThread { requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_START) }
            return "perm"
        }
        cfg.active = true
        val svc = Intent(this, NovaService::class.java)
        runOnUiThread {
            try {
                startForegroundService(svc)
            } catch (e: Exception) {
                cfg.active = false
                pushFlow("start_failed")
            }
        }
        return "started"
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            REQ_START -> pushFlow(startFlow(true))
            REQ_BASIC -> pushFlow("basics_done")
            REQ_CONTACTS -> {
                val ok = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
                pushFlow(if (ok) "contacts_ok" else "contacts_denied")
            }
        }
    }

    /** Tells the page the result of an asynchronous action (the page defines onFlow). */
    private fun pushFlow(status: String) {
        runOnUiThread {
            if (!isDestroyed) {
                web.evaluateJavascript(
                    "if(window.onFlow)onFlow(" + JSONObject.quote(status) + ")", null
                )
            }
        }
    }

    // ---- FIXIMG1: picked photo + AI image (explicit user taps only)
    private var pickedPhoto: ByteArray? = null
    @Volatile private var imgBusy = false

    private fun runJs(js: String) {
        runOnUiThread { if (!isDestroyed) web.evaluateJavascript(js, null) }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PICK || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        Thread {
            try {
                val raw = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                if (raw == null || raw.isEmpty()) { runJs("onPhotoErr('Photo padh nahi paya')"); return@Thread }
                if (raw.size > 30000000) { runJs("onPhotoErr('Photo bahut badi hai')"); return@Thread }
                val small = ImageGen.shrink(raw, 1280)
                if (small == null) { runJs("onPhotoErr('Ye photo format nahi padh paya')"); return@Thread }
                pickedPhoto = small
                val thumb = ImageGen.shrink(small, 160) ?: small
                runJs("onPhoto(" + JSONObject.quote(ImageGen.b64(thumb)) + ")")
            } catch (e: Throwable) {
                runJs("onPhotoErr('Photo padhne mein dikkat')")
            }
        }.start()
    }

    @Volatile private var pubBusy = false

    private fun startPublish(subject: String, html: String) {
        pubBusy = true
        Thread {
            var js: String
            try {
                val r = GitHubPublish.run(this, subject, html)
                js = "onPublish(" + r.ok + "," + JSONObject.quote(r.msg) + "," + JSONObject.quote(r.url) + ")"
            } catch (e: Throwable) {
                js = "onPublish(false," + JSONObject.quote("Publish karte waqt dikkat aayi") + ",\"\")"
            }
            pubBusy = false
            runJs(js)
        }.start()
    }

    private fun startImage(prompt: String, photo: ByteArray?) {
        imgBusy = true
        Thread {
            var js = ""
            try {
                val full = if (photo != null)
                    "Edit the attached photo exactly as requested and keep everything else, especially faces and identity, unchanged. Request: " + prompt
                else prompt
                val r = ImageGen.generate(this, full, photo)
                var thumb = ""
                var saved = ""
                val img = r.img
                if (r.ok && img != null) {
                    saved = ImageGen.saveToGallery(this, img) ?: ""
                    thumb = ImageGen.b64(ImageGen.shrink(img, 1024) ?: img)
                }
                val good = r.ok && thumb.isNotEmpty()
                js = "onImage(" + good + "," + JSONObject.quote(r.msg) + "," + JSONObject.quote(thumb) + "," + JSONObject.quote(saved) + ")"
            } catch (e: Throwable) {
                js = "onImage(false," + JSONObject.quote("Image banate waqt dikkat aayi") + ",\"\",\"\")"
            }
            imgBusy = false
            runJs(js)
        }.start()
    }

    // ---- FIXTEST: image API test (asks first, may cost a little)
    private fun runImageTest() {
        imgBusy = true
        Thread {
            var line = ""
            try {
                val r = ImageGen.generateDirect(this, "A plain blue circle on a white background, minimal", null)
                val img = r.img
                if (r.ok && img != null) {
                    val saved = ImageGen.saveToGallery(this, img)
                    line = "PASS  Image banana: image mili (" + (img.size / 1024) + " KB). Gallery save: " + (saved ?: "FAIL")
                } else {
                    line = "FAIL  Image banana: " + r.msg
                }
            } catch (e: Throwable) {
                line = "FAIL  Image test beech mein ruk gaya"
            }
            imgBusy = false
            runJs("onSelfTest(" + JSONObject.quote(line) + ")")
        }.start()
    }

    // FIXFREE2: tests each free image provider one by one (text-only prompt, no photo)
    private fun runFreeImageTest() {
        imgBusy = true
        Thread {
            try {
                FreeImage.testAll(this) { l -> runJs("onSelfTest(" + JSONObject.quote(l) + ")") }
            } catch (e: Throwable) {
                runJs("onSelfTest(" + JSONObject.quote("FAIL  Free image test beech mein ruk gaya") + ")")
            }
            imgBusy = false
        }.start()
    }

    inner class Bridge {
        @JavascriptInterface
        fun vibrate(ms: Int) { vibe(ms.toLong().coerceIn(5L, 400L)) }

        @JavascriptInterface
        fun running() = NovaService.running

        @JavascriptInterface
        fun hasKey() = SecureStore.hasKeys(this@MainActivity)

        /** Keys are only ever written here, never sent back to the page. */
        @JavascriptInterface
        fun saveKeys(raw: String): String = try {
            val keys = Logic.parseKeys(raw)
            if (keys.isEmpty()) "invalid"
            else if (SecureStore.saveKeys(this@MainActivity, keys)) "ok:" + keys.size
            else "fail"
        } catch (e: Exception) { "fail" }

        @JavascriptInterface
        fun keyCount(): Int = SecureStore.getKeys(this@MainActivity).size

        @JavascriptInterface
        fun clearKey() { SecureStore.clearKeys(this@MainActivity) }

        @JavascriptInterface
        fun stopSpeak() { NovaService.instance?.stopSpeaking() }

        @JavascriptInterface
        fun sendText(t: String): String = NovaService.instance?.typed(t.take(500)) ?: "off"

        @JavascriptInterface
        fun wakeNow() { NovaService.instance?.wakeNow() }

        @JavascriptInterface
        fun selfTest(): String {
            if (SelfTest.running) return "busy"
            SelfTest.start(
                this@MainActivity,
                { l -> runJs("onSelfTest(" + JSONObject.quote(l) + ")") },
                { rep -> runJs("onSelfTestDone(" + JSONObject.quote(rep) + ")") }
            )
            return "started"
        }

        @JavascriptInterface
        fun getFreeImg(): Boolean = FreeImage.enabled(this@MainActivity)

        @JavascriptInterface
        fun setFreeImg(on: Boolean): String {
            FreeImage.setEnabled(this@MainActivity, on)
            return "ok"
        }

        @JavascriptInterface
        fun selfTestFree(): String {
            if (imgBusy) return "busy"
            runOnUiThread {
                try {
                    android.app.AlertDialog.Builder(this@MainActivity, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                        .setTitle("Free image test karein?")
                        .setMessage("Har free provider ko ek chhota text prompt jaayega (koi photo nahi). Together aur Hugging Face tabhi jab unki key saved ho. Hugging Face par paise lag sakte hain. 1-2 minute lag sakte hain.")
                        .setPositiveButton("HAAN") { _, _ -> runFreeImageTest() }
                        .setNegativeButton("NAHI", null)
                        .show()
                } catch (e: Exception) {
                }
            }
            return "asking"
        }

        @JavascriptInterface
        fun selfTestImage(): String {
            if (!SecureStore.hasKeys(this@MainActivity)) return "nokey"
            if (imgBusy) return "busy"
            runOnUiThread {
                try {
                    android.app.AlertDialog.Builder(this@MainActivity, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                        .setTitle("Image test karein?")
                        .setMessage("Gemini se 1 chhoti image banegi. Billing wali key par thoda paisa lag sakta hai.")
                        .setPositiveButton("HAAN") { _, _ -> runImageTest() }
                        .setNegativeButton("NAHI", null)
                        .show()
                } catch (e: Exception) {
                }
            }
            return "asking"
        }

        @JavascriptInterface
        fun copyText(t: String): String = try {
            val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("NOVA report", t.take(20000)))
            "ok"
        } catch (e: Exception) { "fail" }

        @JavascriptInterface
        fun shareText(t: String): String {
            runOnUiThread {
                try {
                    val i = Intent(Intent.ACTION_SEND)
                    i.type = "text/plain"
                    i.putExtra(Intent.EXTRA_TEXT, t.take(20000))
                    startActivity(Intent.createChooser(i, "Report bhejo"))
                } catch (e: Exception) {
                }
            }
            return "ok"
        }

        @JavascriptInterface
        fun pickPhoto(): String {
            runOnUiThread {
                try {
                    val i = Intent(Intent.ACTION_GET_CONTENT)
                    i.type = "image/*"
                    i.addCategory(Intent.CATEGORY_OPENABLE)
                    startActivityForResult(Intent.createChooser(i, "Photo chuno"), REQ_PICK)
                } catch (e: Exception) {
                    runJs("onPhotoErr('Gallery nahi khuli')")
                }
            }
            return "ok"
        }

        @JavascriptInterface
        fun clearPhoto() { pickedPhoto = null }

        /** started / asking (waits for the HAAN tap) / busy / nokey / empty. A photo is only uploaded after that tap. */
        @JavascriptInterface
        fun makeImage(prompt: String): String {
            val p = prompt.trim().take(800)
            if (p.isEmpty()) return "empty"
            if (!SecureStore.hasKeys(this@MainActivity)) return "nokey"
            if (imgBusy) return "busy"
            val photo = pickedPhoto
            if (photo == null) { startImage(p, null); return "started" }
            runOnUiThread {
                try {
                    android.app.AlertDialog.Builder(this@MainActivity, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                        .setTitle("Photo Google ko bhejein?")
                        .setMessage("Ye photo edit ke liye internet par Google Gemini ko bheji jayegi.")
                        .setPositiveButton("HAAN, BHEJO") { _, _ -> startImage(p, photo) }
                        .setNegativeButton("NAHI") { _, _ -> runJs("onImgCancel()") }
                        .setOnCancelListener { runJs("onImgCancel()") }
                        .show()
                } catch (e: Exception) {
                    runJs("onImgCancel()")
                }
            }
            return "asking"
        }

        /** The optional Groq key is only ever written here, never sent back to the page. ok / invalid / fail. */
        @JavascriptInterface
        fun saveGroqKey(raw: String): String = try {
            val k = raw.trim()
            if (k.length < 20 || k.length > 200 || k.any { it.isWhitespace() }) "invalid"
            else if (SecureStore.saveGroq(this@MainActivity, k)) "ok"
            else "fail"
        } catch (e: Exception) { "fail" }

        @JavascriptInterface
        fun hasGroqKey(): Boolean = SecureStore.hasGroq(this@MainActivity)

        /** Seconds NOVA waits after you stop speaking (2 to 10). */
        @JavascriptInterface
        fun getWaitSec(): Int = ExtCfg.waitSec(this@MainActivity)

        @JavascriptInterface
        fun setWaitSec(sec: Int): String { ExtCfg.setWaitSec(this@MainActivity, sec); return "ok" }

        @JavascriptInterface
        fun clearGroqKey() { SecureStore.clearGroq(this@MainActivity) }

        /** Optional OpenRouter key for the free AI chain. Written only here, never sent back to the page. ok / invalid / fail. */
        @JavascriptInterface
        fun saveOpenRouterKey(raw: String): String = try {
            val k = raw.trim()
            if (k.length < 20 || k.length > 200 || k.any { it.isWhitespace() }) "invalid"
            else if (SecureStore.saveSlot(this@MainActivity, "openrouter", k)) "ok"
            else "fail"
        } catch (e: Exception) { "fail" }

        @JavascriptInterface
        fun hasOpenRouterKey(): Boolean = SecureStore.hasSlot(this@MainActivity, "openrouter")

        @JavascriptInterface
        fun clearOpenRouterKey() { SecureStore.clearSlot(this@MainActivity, "openrouter") }

        /** Optional Z.ai (Zhipu GLM, free Flash models) key for the free AI chain. Written only here, never sent back. ok / invalid / fail. */
        @JavascriptInterface
        fun saveZaiKey(raw: String): String = try {
            val k = raw.trim()
            if (k.length < 20 || k.length > 200 || k.any { it.isWhitespace() }) "invalid"
            else if (SecureStore.saveSlot(this@MainActivity, "zai", k)) "ok"
            else "fail"
        } catch (e: Exception) { "fail" }

        @JavascriptInterface
        fun hasZaiKey(): Boolean = SecureStore.hasSlot(this@MainActivity, "zai")

        @JavascriptInterface
        fun clearZaiKey() { SecureStore.clearSlot(this@MainActivity, "zai") }

        @JavascriptInterface
        fun getFreeChain(): Boolean = ExtCfg.freeChain(this@MainActivity)

        @JavascriptInterface
        fun setFreeChain(on: Boolean): String { ExtCfg.setFreeChain(this@MainActivity, on); return "ok" }

        // PART 2 personal memory: the page only gets a COUNT, and the text only after the owner taps SHOW.
        @JavascriptInterface
        fun getMemoryCount(): Int = PersonalMemoryStore.count(this@MainActivity)

        @JavascriptInterface
        fun getMemoryText(): String = PersonalMemory.encode(PersonalMemoryStore.load(this@MainActivity))

        @JavascriptInterface
        fun clearMemory(): String = if (PersonalMemoryStore.clear(this@MainActivity)) "ok" else "fail"

        @JavascriptInterface
        fun getMemoryInChain(): Boolean = ExtCfg.memoryInChain(this@MainActivity)

        @JavascriptInterface
        fun setMemoryInChain(on: Boolean): String { ExtCfg.setMemoryInChain(this@MainActivity, on); return "ok" }

        /** GitHub token for publishing a website. Written only here, never sent back to the page. ok / invalid / fail. */
        @JavascriptInterface
        fun saveGithubToken(raw: String): String = try {
            val k = raw.trim()
            if (k.length < 20 || k.length > 255 || k.any { it.isWhitespace() }) "invalid"
            else if (SecureStore.saveSlot(this@MainActivity, GitHubPublish.SLOT, k)) "ok"
            else "fail"
        } catch (e: Exception) { "fail" }

        @JavascriptInterface
        fun hasGithubToken(): Boolean = SecureStore.hasSlot(this@MainActivity, GitHubPublish.SLOT)

        @JavascriptInterface
        fun clearGithubToken() { SecureStore.clearSlot(this@MainActivity, GitHubPublish.SLOT) }

        /** PUBLISH button in the chat. A native box asks first; nothing leaves the phone before HAAN. nosite / notoken / busy / asking. */
        @JavascriptInterface
        fun publishLastSite(): String {
            val html = NovaService.lastSiteHtml
            val subject = NovaService.lastSiteSubject
            if (html.isEmpty()) return "nosite"
            if (!SecureStore.hasSlot(this@MainActivity, GitHubPublish.SLOT)) return "notoken"
            if (pubBusy) return "busy"
            runOnUiThread {
                try {
                    android.app.AlertDialog.Builder(this@MainActivity, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                        .setTitle("Website publish karein?")
                        .setMessage("Tumhare GitHub account mein ek nayi PUBLIC repo banegi aur website internet par sabko dikhegi. Baad mein repo GitHub se hata sakte ho.")
                        .setPositiveButton("HAAN") { _, _ -> startPublish(subject, html) }
                        .setNegativeButton("NAHI", null)
                        .show()
                } catch (e: Exception) {
                }
            }
            return "asking"
        }

        /** Opens the published page in the browser. Only https://<name>.github.io/ links. */
        @JavascriptInterface
        fun openPublished(url: String) {
            if (!url.startsWith("https://") || !url.contains(".github.io/")) return
            runOnUiThread {
                try {
                    startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url)))
                } catch (e: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun getLearned(): String = LearnStore.listJson(this@MainActivity)

        @JavascriptInterface
        fun keepLearned(id: String): String = if (LearnStore.keep(this@MainActivity, id)) "ok" else "fail"

        @JavascriptInterface
        fun deleteLearned(id: String): String = if (LearnStore.delete(this@MainActivity, id)) "ok" else "fail"

        @JavascriptInterface
        fun clearLearned(): String { LearnStore.clear(this@MainActivity); return "ok" }

        @JavascriptInterface
        fun getAlerts(): Boolean = ExtCfg.alerts(this@MainActivity)

        @JavascriptInterface
        fun setAlerts(on: Boolean): String { ExtCfg.setAlerts(this@MainActivity, on); return "ok" }

        @JavascriptInterface
        fun getConvo(): Boolean = ExtCfg.convo(this@MainActivity)

        @JavascriptInterface
        fun setConvo(on: Boolean): String { ExtCfg.setConvo(this@MainActivity, on); return "ok" }

        @JavascriptInterface
        fun getAutoModels(): Boolean = ExtCfg.autoModels(this@MainActivity)

        @JavascriptInterface
        fun setAutoModels(on: Boolean): String { ExtCfg.setAutoModels(this@MainActivity, on); return "ok" }

        @JavascriptInterface
        fun voiceModelReady(): Boolean = VoiceLock.modelReady(this@MainActivity)

        @JavascriptInterface
        fun downloadVoiceModel(): String = ModelAuto.manualVoice(this@MainActivity)

        @JavascriptInterface
        fun brainEngineReady(): Boolean = LocalBrains.factory != null

        @JavascriptInterface
        fun getVoiceLock(): Boolean = ExtCfg.voiceLock(this@MainActivity) && VoiceLock.hasProfile(this@MainActivity)

        @JavascriptInterface
        fun getVoiceLevel(): Int = ExtCfg.voiceLevel(this@MainActivity)

        @JavascriptInterface
        fun setVoiceLevel(level: Int): String { ExtCfg.setVoiceLevel(this@MainActivity, level); return "ok" }

        @JavascriptInterface
        fun hasVoiceProfile(): Boolean = VoiceLock.hasProfile(this@MainActivity)

        @JavascriptInterface
        fun setVoiceLock(on: Boolean): String {
            if (on && !VoiceLock.hasProfile(this@MainActivity)) return "noprofile"
            ExtCfg.setVoiceLock(this@MainActivity, on)
            return "ok"
        }

        @JavascriptInterface
        fun voiceEnroll(): String = NovaService.instance?.startVoiceEnroll() ?: "notrunning"

        @JavascriptInterface
        fun voiceDelete(): String {
            VoiceLock.deleteProfile(this@MainActivity)
            ExtCfg.setVoiceLock(this@MainActivity, false)
            return "ok"
        }

        @JavascriptInterface
        fun getFreeKeyless(): Boolean = ExtCfg.freeKeyless(this@MainActivity)

        @JavascriptInterface
        fun setFreeKeyless(on: Boolean): String { ExtCfg.setFreeKeyless(this@MainActivity, on); return "ok" }

        // FIXFREE1: optional free image provider keys (together / hf). Written only here, never sent back to the page.
        @JavascriptInterface
        fun saveImgKey(slot: String, raw: String): String = try {
            val k = raw.trim()
            if (slot != "together" && slot != "hf") "invalid"
            else if (k.length < 10 || k.length > 300 || k.any { it.isWhitespace() }) "invalid"
            else if (SecureStore.saveSlot(this@MainActivity, slot, k)) "ok"
            else "fail"
        } catch (e: Exception) { "fail" }

        @JavascriptInterface
        fun hasImgKey(slot: String): Boolean = (slot == "together" || slot == "hf") && SecureStore.hasSlot(this@MainActivity, slot)

        @JavascriptInterface
        fun clearImgKey(slot: String) {
            if (slot == "together" || slot == "hf") SecureStore.clearSlot(this@MainActivity, slot)
        }

        @JavascriptInterface
        fun toggle(): String {
            if (NovaService.running) {
                cfg.active = false
                runOnUiThread { stopService(Intent(this@MainActivity, NovaService::class.java)) }
                return "stopped"
            }
            return startFlow(false)
        }

        /** READ_CONTACTS is requested here, on a user tap, and nowhere else. */
        @JavascriptInterface
        fun requestContacts(): String {
            if (granted(Manifest.permission.READ_CONTACTS)) return "granted"
            runOnUiThread { requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), REQ_CONTACTS) }
            return "asked"
        }

        /** Brightness control needs the special "Modify system settings" permission; the user opens it here. */
        @JavascriptInterface
        fun openWriteSettings() {
            runOnUiThread {
                try {
                    startActivity(
                        Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))
                    )
                } catch (e: Exception) {
                    pushFlow("write_settings_failed")
                }
            }
        }

        /** The floating NOVA card needs "Display over other apps"; the user opens it here. */
        @JavascriptInterface
        fun openOverlaySettings() {
            runOnUiThread {
                try {
                    startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                    )
                } catch (e: Exception) {
                    pushFlow("overlay_settings_failed")
                }
            }
        }

        // ---------------------------------------------------------------- Update Center (what is new / what is missing)

        /** One snapshot for the Update Center page: version + which permissions are on. Nothing is changed here. */
        @JavascriptInterface
        fun getStatus(): String {
            val vName = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
            return JSONObject()
                .put("versionName", vName)
                .put("versionCode", UpdateManager.appVersion(this@MainActivity))
                .put("mic", granted(Manifest.permission.RECORD_AUDIO))
                .put("notif", Build.VERSION.SDK_INT < 33 || granted(Manifest.permission.POST_NOTIFICATIONS))
                .put("overlay", Settings.canDrawOverlays(this@MainActivity))
                .put("acc", NovaAccessibilityService.isEnabled(this@MainActivity))
                .put("notifAccess", DrivingBridge.listenerEnabled(this@MainActivity))
                .put("installOk", packageManager.canRequestPackageInstalls())
                .put("assistant", isDefaultAssistant())
                .put("contacts", granted(Manifest.permission.READ_CONTACTS))
                .put("writeSettings", Settings.System.canWrite(this@MainActivity))
                .put("battery", (getSystemService(POWER_SERVICE) as? android.os.PowerManager)?.isIgnoringBatteryOptimizations(packageName) == true)
                .put("pattern", PatternUnlock.isSet(this@MainActivity))
                .put("feedUrl", cfg.feedUrl)
                .put("running", NovaService.running)
                .put("engine", LocalBrains.factory != null)
                .put("ramMb", totalRamMb())
                .put("ramOk", ModelCatalog.ramOk(totalRamMb()))
                .put("brainInstalled", UpdateManager.activeModelPath(this@MainActivity).isNotEmpty())
                .toString()
        }

        private fun totalRamMb(): Long {
            val am = getSystemService(ACTIVITY_SERVICE) as? android.app.ActivityManager ?: return 0L
            val mi = android.app.ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            return mi.totalMem / (1024L * 1024L)
        }

        /** Puts the built-in offline model on the offer list (nothing is downloaded). "ok" or a short reason. */
        @JavascriptInterface
        fun offerOfflineBrain(): String = UpdateManager.offerOfflineBrain(this@MainActivity) ?: "ok"

        /** Asks Android to stop limiting NOVA's battery use (so the mic service is not killed). The user taps Allow. */
        @JavascriptInterface
        fun openBatterySettings() {
            runOnUiThread {
                val tries = listOf(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")),
                    Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS),
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                )
                for (i in tries) {
                    try { startActivity(i); return@runOnUiThread } catch (e: Exception) { }
                }
                pushFlow("update_msg:Open Settings > Apps > NOVA > Battery > No restrictions")
            }
        }

        /** Opens NOVA's own pattern-unlock screen (it no longer has its own launcher icon). */
        @JavascriptInterface
        fun openPatternSetup() {
            runOnUiThread {
                try { startActivity(Intent(this@MainActivity, PatternSetupActivity::class.java)) } catch (e: Exception) { }
            }
        }

        /** Opens Android's own "Default digital assistant app" choice. The user picks NOVA there; NOVA cannot set it by itself. */
        @JavascriptInterface
        fun openAssistantSettings() {
            runOnUiThread {
                val tries = listOf(
                    Intent(Settings.ACTION_VOICE_INPUT_SETTINGS),
                    Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS),
                    Intent(Settings.ACTION_SETTINGS)
                )
                for (i in tries) {
                    try { startActivity(i); return@runOnUiThread } catch (e: Exception) { }
                }
                pushFlow("update_msg:Settings could not be opened. Open Settings > Apps > Default apps > Digital assistant app")
            }
        }

        /** Asks Android for the microphone and notification permission (the user sees the normal Android dialog). */
        @JavascriptInterface
        fun requestBasics(): String {
            val ask = ArrayList<String>()
            if (!granted(Manifest.permission.RECORD_AUDIO)) ask.add(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) {
                ask.add(Manifest.permission.POST_NOTIFICATIONS)
            }
            if (ask.isEmpty()) return "ok"
            // Android stops showing the popup after two denials; then the button looked dead and the Update Center
            // seemed stuck. In that case open this app's settings page instead.
            val prefs = getSharedPreferences("nova_perm", android.content.Context.MODE_PRIVATE)
            val askedBefore = prefs.getBoolean("basics_asked", false)
            val blocked = askedBefore && ask.all { !shouldShowRequestPermissionRationale(it) }
            if (blocked) {
                runOnUiThread {
                    try {
                        val i = Intent(
                            android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            android.net.Uri.parse("package:" + packageName)
                        )
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(i)
                    } catch (e: Exception) {
                        pushFlow("basics_done")
                    }
                }
                return "settings"
            }
            prefs.edit().putBoolean("basics_asked", true).apply()
            runOnUiThread { requestPermissions(ask.toTypedArray(), REQ_BASIC) }
            return "asked"
        }

        /** Driving mode reads messages only after the user switches "Notification access" on for NOVA. */
        @JavascriptInterface
        fun openNotificationAccess() {
            runOnUiThread { DrivingBridge.openListenerSettings(this@MainActivity) }
        }

        // ---------------------------------------------------------------- updates (Discover -> Ask -> Add)

        /** "ok" or "bad" (the feed URL must be https). An empty URL turns update checks off. */
        @JavascriptInterface
        fun setFeedUrl(url: String): String {
            val u = url.trim()
            if (u.isEmpty()) { cfg.feedUrl = ""; return "ok" }
            if (!Updater.feedUrlOk(u)) return "bad"
            cfg.feedUrl = u
            return "ok"
        }

        @JavascriptInterface
        fun checkUpdates() {
            val url = cfg.feedUrl
            Thread {
                val e = if (url.isBlank()) "set the feed URL first" else UpdateManager.refresh(this@MainActivity, url)
                pushFlow(if (e == null) "updates_ok" else "updates_err:$e")
            }.start()
        }

        /** {"offers":[{id,type,title,sizeText,status}],"installed":{id:version}} */
        @JavascriptInterface
        fun getUpdates(): String {
            val arr = JSONArray()
            for (o in UpdateManager.offers(this@MainActivity)) {
                arr.put(
                    JSONObject().put("id", o.item.id).put("type", o.item.type).put("title", o.item.title)
                        .put("sizeText", Updater.sizeText(o.item.size)).put("status", o.status)
                )
            }
            return JSONObject().put("offers", arr)
                .put("installed", JSONObject(UpdateManager.installedJson(this@MainActivity))).toString()
        }

        /** Only the user's tap on INSTALL calls this. The download is verified (https, host list, SHA-256, size). */
        @JavascriptInterface
        fun installUpdate(id: String): String {
            UpdateManager.install(this@MainActivity, id) { ok, msg ->
                if (!ok || msg.isNotEmpty()) pushFlow("update_msg:$msg")
            }
            return "started"
        }

        @JavascriptInterface
        fun skipUpdate(id: String): String { UpdateManager.skip(this@MainActivity, id); return "ok" }

        @JavascriptInterface
        fun rollbackUpdate(id: String): String = UpdateManager.rollback(this@MainActivity, id)

        /** "Install unknown apps" for NOVA - needed once, only for installing a new NOVA version. */
        @JavascriptInterface
        fun openInstallSettings() {
            runOnUiThread {
                try {
                    startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
                } catch (e: Exception) {
                    pushFlow("update_msg:Settings could not be opened. Use APP INFO > Install unknown apps")
                }
            }
        }

        /** {"skills":n,"events":n,"learned":n} - how much NOVA has learned on this phone. */
        @JavascriptInterface
        fun brainStats(): String = BrainStore.get(this@MainActivity).statsJson()

        /** Wipes all learned shortcuts and the local event log. */
        @JavascriptInterface
        fun brainClear(): String {
            BrainStore.get(this@MainActivity).clear()
            return "ok"
        }

        @JavascriptInterface
        fun getSettings(): String {
            val keyCount = SecureStore.getKeys(this@MainActivity).size
            val hasKey = SecureStore.hasKeys(this@MainActivity)
            return JSONObject()
                .put("wake", cfg.wake)
                .put("lang", cfg.lang)
                .put("rate", cfg.rate.toDouble())
                .put("pitch", cfg.pitch.toDouble())
                .put("model", cfg.model)
                .put("models", JSONArray(Logic.MODELS))
                .put("autostart", cfg.autostart)
                .put("hasKey", hasKey)
                .put("keyCount", keyCount)
                .put("hasGroq", SecureStore.hasGroq(this@MainActivity))
                .put("localMode", !hasKey)
                .put("acc", NovaAccessibilityService.isEnabled(this@MainActivity))
                .put("screenMonitor", cfg.screenMonitor)
                .put("contacts", granted(Manifest.permission.READ_CONTACTS))
                .put("writeSettings", Settings.System.canWrite(this@MainActivity))
                .put("overlay", Settings.canDrawOverlays(this@MainActivity))
                .put("feedUrl", cfg.feedUrl)
                .put("running", NovaService.running)
                .toString()
        }

        /** Returns ok, need_acc (everything saved but screen monitoring stayed OFF), bad_wake or error. */
        @JavascriptInterface
        fun saveSettings(json: String): String {
            return try {
                val o = JSONObject(json)
                val w = Logic.cleanWake(o.optString("wake"))
                if (w == null) {
                    "bad_wake"
                } else {
                    cfg.wake = w
                    cfg.lang = if (o.optString("lang") == "en") "en" else "hi"
                    cfg.rate = Logic.clampRate(o.optDouble("rate", 1.0).toFloat())
                    cfg.pitch = Logic.clampPitch(o.optDouble("pitch", 1.0).toFloat())
                    cfg.model = Logic.cleanModel(o.optString("model"))
                    cfg.autostart = o.optBoolean("autostart", true)
                    val wantMonitor = o.optBoolean("screenMonitor", false)
                    val accOn = NovaAccessibilityService.isEnabled(this@MainActivity)
                    val before = cfg.screenMonitor
                    cfg.screenMonitor = wantMonitor && accOn
                    if (before != cfg.screenMonitor) NovaAccessibilityService.monitorChanged()
                    NovaService.instance?.reloadVoice()
                    if (wantMonitor && !accOn) "need_acc" else "ok"
                }
            } catch (e: Exception) {
                "error"
            }
        }

        @JavascriptInterface
        fun testVoice() {
            runOnUiThread {
                val text = if (cfg.lang == "en") "Hello, I am Nova" else "नमस्ते, मैं नोवा हूँ"
                val svc = NovaService.instance
                if (svc != null) {
                    svc.speakTest(text)
                } else {
                    testTts?.shutdown()
                    var created: TextToSpeech? = null
                    created = TextToSpeech(this@MainActivity) { st ->
                        if (st == TextToSpeech.SUCCESS) {
                            cfg.applyVoice(created)
                            created?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "test")
                        }
                    }
                    testTts = created
                }
            }
        }

        @JavascriptInterface
        fun openAccessibility() {
            runOnUiThread { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }

        @JavascriptInterface
        fun openAppInfo() {
            runOnUiThread {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                )
            }
        }
    }

    private companion object {
        const val ASSET_URL = "file:///android_asset/ui.html"
        const val ASSET_PREFIX = "file:///android_asset/"
        const val REQ_START = 1
        const val REQ_CONTACTS = 2
        const val REQ_BASIC = 3
        const val REQ_PICK = 4
    }
}
